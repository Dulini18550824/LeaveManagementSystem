<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FileUpload extends Model
{
    protected $fillable = ['id', 'leave_id', 'file_name', 'location'];

    public function leave(){
        return $this->belongsTo('App\Leave');
    }
}
