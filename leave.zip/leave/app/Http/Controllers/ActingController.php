<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Leave;
use Carbon\Carbon;


class ActingController extends Controller
{
    public function index(){

        //$users = User::where('user_type', User::TYPE_EMPLOYEE)->with('team')->get();
        $users = User::where('user_type', User::TYPE_EMPLOYEE)
            ->whereIn('team_id',['1','2','3','4'])
            ->where('is_verified', 'true')
            ->with('team')
            ->get();

        return view('acting.index', ['users'=>$users]);
    }

    public function makeActing($user_id){
        $user = User::find($user_id);

        //----------------------acting user leave validation
        $user_leaves = Leave::where('user_id', $user_id)->get();
        $carbon_start_date = Carbon::now();
    
        $leaves_filter = $user_leaves->filter(function($item) use ($carbon_start_date) {
            if ($carbon_start_date->between($item->start_date, $item->end_date)) {
                return $item;
            }
        });

        if ($leaves_filter->count() > 0) {
            return response()->json([
                'states' => 1002,
                'data' => 'Employee on leave'
            ]);
        }
        //----------------------------------------

        $user->is_acting = 2;
        $user->save();

        if($user){
            return response()->json([
                'states' => 200,
                'data' => 'Success'
            ]);
        }else{
            return response()->json([
                'states' => 1002,
                'data' => 'Fail'
            ]);
        }
    }

    public function removeActing($user_id){
        $user = User::find($user_id);
        $user->is_acting = 0;
        $user->save();

        if($user){
            return response()->json([
                'states' => 200,
                'data' => 'Success'
            ]);
        }else{
            return response()->json([
                'states' => 1002,
                'data' => 'Fail'
            ]);
        }
    }

    public function acceptActing() {
        $user = User::where('id', auth()->user()->id)->firstOrFail();
        if ($user->is_acting == '2') {
            $user->update(['is_acting' => 1]);
            return redirect()->back();
        } else {
            abort(403);
        }
    }

    public function rejectActing() {
        $user = User::where('id', auth()->user()->id)->firstOrFail();
        if ($user->is_acting == '2') {
            $user->update(['is_acting' => 0]);
            return redirect()->back();
        } else {
            abort(403);
        }
    }
}
