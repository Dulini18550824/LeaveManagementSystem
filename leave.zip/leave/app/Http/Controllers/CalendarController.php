<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DateTime;
use App\Leave;
use App\LeaveType;
use App\Holiday;
use App\User;
use Carbon\CarbonPeriod;

class CalendarController extends Controller
{
    public function getLeave($id=NULL){

        if($id != NULL){
            $user_id = $id;
        }else{
            $user_id = \Auth::id();
        }

        $formattedAllLeaves = [];
        // Casual leaves
        $casualLeaves = Leave::where('user_id', $user_id)->where('status', 1)->where('leave_type', LeaveType::CASSUAL)->get();
        
        $allLeaves = [];
        $dates = [];

        if($casualLeaves->isNotEmpty()){
            foreach($casualLeaves as $leave){
    
                // To remove weekends, Date of commencing leave and holidays
                $startDateTime = DateTime::createFromFormat('Y-m-d H:i:s', $leave->start_date);
                $start = $startDateTime->format('Y-m-d');
                $endDateTime = DateTime::createFromFormat('Y-m-d H:i:s', $leave->end_date);
                $end = $endDateTime->format('Y-m-d');

                $period = CarbonPeriod::create($start , $end);
                $allLeaves = [];
                
                $holidays = Holiday::get()->pluck('date')->toArray();

                if($start<$end){
                    foreach($period as $key => $dt) {
                        $tem = $dt->format('Y-m-d');
                        if(!\Carbon\Carbon::parse($tem)->isWeekend() 
                        && array_key_last($period->toArray()) != $key
                        && !in_array($tem, $holidays)){
                            array_push($allLeaves, $dt->format('Y-m-d'));
                        }
                    }
                }
            }
    
            $formatAllLeaves = [];
            $temp = [];
            foreach($allLeaves as $allLeave){
                $temp = [
                    'date' => $allLeave,
                    'color'  => '#3341FF'
                ];
                array_push($formatAllLeaves,$temp);
            }
            array_push($formattedAllLeaves, $formatAllLeaves);
        }

        // Vacation leaves
        $vacationLeaves = Leave::where('user_id', $user_id)->where('status', 1)->where('leave_type', LeaveType::VACASION)->get();

        $allLeaves = [];
        $dates = [];

        if($vacationLeaves->isNotEmpty()){
            foreach($vacationLeaves as $leave){
    
                // To remove weekends, Date of commencing leave and holidays
                $startDateTime = DateTime::createFromFormat('Y-m-d H:i:s', $leave->start_date);
                $start = $startDateTime->format('Y-m-d');
                $endDateTime = DateTime::createFromFormat('Y-m-d H:i:s', $leave->end_date);
                $end = $endDateTime->format('Y-m-d');

                $period = CarbonPeriod::create($start , $end);
                $allLeaves = [];
                
                $holidays = Holiday::get()->pluck('date')->toArray();

                if($start<$end){
                    foreach($period as $key => $dt) {
                        $tem = $dt->format('Y-m-d');
                        if(!\Carbon\Carbon::parse($tem)->isWeekend() 
                        && array_key_last($period->toArray()) != $key
                        && !in_array($tem, $holidays)){
                            array_push($allLeaves, $dt->format('Y-m-d'));
                        }
                    }
                }
            }
    
            $formatAllLeaves = [];
            $temp = [];
            foreach($allLeaves as $allLeave){
                $temp = [
                    'date' => $allLeave,
                    'color'  => '#AB2438'
                ];
                array_push($formatAllLeaves,$temp);
            }
            array_push($formattedAllLeaves, $formatAllLeaves);
        }

        // Other leaves
        $otherLeaves = Leave::where('user_id', $user_id)->where('status', 1)->where('leave_type', LeaveType::OTHER)->get();

        $allLeaves = [];
        $dates = [];

        if($otherLeaves->isNotEmpty()){
            foreach($otherLeaves as $leave){
    
                // To remove weekends, Date of commencing leave and holidays
                $startDateTime = DateTime::createFromFormat('Y-m-d H:i:s', $leave->start_date);
                $start = $startDateTime->format('Y-m-d');
                $endDateTime = DateTime::createFromFormat('Y-m-d H:i:s', $leave->end_date);
                $end = $endDateTime->format('Y-m-d');

                $period = CarbonPeriod::create($start , $end);
                $allLeaves = [];
                
                $holidays = Holiday::get()->pluck('date')->toArray();

                if($start<$end){
                    foreach($period as $key => $dt) {
                        $tem = $dt->format('Y-m-d');
                        if(!\Carbon\Carbon::parse($tem)->isWeekend() 
                        && array_key_last($period->toArray()) != $key
                        && !in_array($tem, $holidays)){
                            array_push($allLeaves, $dt->format('Y-m-d'));
                        }
                    }
                }
            }
    
            $formatAllLeaves = [];
            $temp = [];
            foreach($allLeaves as $allLeave){
                $temp = [
                    'date' => $allLeave,
                    'color'  => '#277115'
                ];
                array_push($formatAllLeaves,$temp);
            }
            array_push($formattedAllLeaves, $formatAllLeaves);
        }

        // Special leaves
        $specialLeaves = Leave::where('user_id', $user_id)->where('status', 1)->where('leave_type', LeaveType::SPECIAL)->get();

        $allLeaves = [];
        $dates = [];

        if($specialLeaves->isNotEmpty()){
            foreach($specialLeaves as $leave){
    
                // To remove weekends, Date of commencing leave and holidays
                $startDateTime = DateTime::createFromFormat('Y-m-d H:i:s', $leave->start_date);
                $start = $startDateTime->format('Y-m-d');
                $endDateTime = DateTime::createFromFormat('Y-m-d H:i:s', $leave->end_date);
                $end = $endDateTime->format('Y-m-d');

                $period = CarbonPeriod::create($start , $end);
                $allLeaves = [];
                
                $holidays = Holiday::get()->pluck('date')->toArray();

                if($start<$end){
                    foreach($period as $key => $dt) {
                        $tem = $dt->format('Y-m-d');
                        if(!\Carbon\Carbon::parse($tem)->isWeekend() 
                        && array_key_last($period->toArray()) != $key
                        && !in_array($tem, $holidays)){
                            array_push($allLeaves, $dt->format('Y-m-d'));
                        }
                    }
                }
            }
    
            $formatAllLeaves = [];
            $temp = [];
            foreach($allLeaves as $allLeave){
                $temp = [
                    'date' => $allLeave,
                    'color'  => '#EFF21A'
                ];
                array_push($formatAllLeaves,$temp);
            }
            array_push($formattedAllLeaves, $formatAllLeaves);
        }

        // Short leaves
        $shortLeaves = Leave::where('user_id', $user_id)->where('status', 1)->where('leave_type', LeaveType::SHORT)->get();

        $allLeaves = [];
        $dates = [];

        if($shortLeaves->isNotEmpty()){
            foreach($shortLeaves as $shortLeave){
                $date = DateTime::createFromFormat('Y-m-d H:i:s', $shortLeave->start_date);
                array_push($allLeaves, $date->format('Y-m-d'));
            }

            $formatAllLeaves = [];
            $temp = [];
            foreach($allLeaves as $allLeave){
                $temp = [
                    'date' => $allLeave,
                    'color'  => '#1ACCF2'
                ];
                array_push($formatAllLeaves,$temp);
            }
            array_push($formattedAllLeaves, $formatAllLeaves);
        }

        // Holidays
        $holidays = Holiday::get();

        $allLeaves = [];
        $dates = [];

        if($holidays->isNotEmpty()){
            foreach($holidays as $holiday){
                $date = $holiday->date;
                array_push($allLeaves, $date);
            }

            $formatAllLeaves = [];
            $temp = [];
            foreach($allLeaves as $allLeave){
                $temp = [
                    'date' => $allLeave,
                    'title' => 'Holiday',
                    'color'  => '#FF0000'
                ];
                array_push($formatAllLeaves,$temp);
            }
            array_push($formattedAllLeaves, $formatAllLeaves);
        }
        
        return response()->json([
            'states' => 200,
            'data' => $formattedAllLeaves
        ]);
    }

    public function getuserWiseLeave($id){
        $user_id = $id;

        $user_name = User::find($id);

        $formattedAllLeaves = [];
        // Casual leaves
        $casualLeaves = Leave::where('user_id', $user_id)->where('status', 1)->where('leave_type', LeaveType::CASSUAL)->get();
        
        $allLeaves = [];
        $dates = [];

        if($casualLeaves->isNotEmpty()){
            foreach($casualLeaves as $leave){
    
                $startDateTime = DateTime::createFromFormat('Y-m-d H:i:s', $leave->start_date);
                $start = $startDateTime->format('Y-m-d');
                $endDateTime = DateTime::createFromFormat('Y-m-d H:i:s', $leave->end_date);
                $end = $endDateTime->format('Y-m-d');
    
                $start = new DateTime($start);
                $end = new DateTime($end);
    
                // create an iterateable period of date (P1D equates to 1 day)
                $period = new \DatePeriod($start, new \DateInterval('P1D'), $end);
    
                // best stored as array, so you can add more than one
                $holidays = array('2012-09-07');
    
                if($start<$end){
                    foreach($period as $dt) {
                        $curr = $dt->format('D');
        
                        // substract if Saturday or Sunday
                        if ($curr != 'Sat' || $curr != 'Sun') {
                            array_push($allLeaves, $dt->format('Y-m-d'));
                        }
        
                        // (optional) for the updated question
                        elseif (!in_array($dt->format('Y-m-d'), $holidays)) {
                            array_push($allLeaves, $dt->format('Y-m-d'));
                        }
                    }
                }else{
                    // Push set into parent array
                    array_push($allLeaves, $start->format('Y-m-d'));
                }
            }
    
            $formatAllLeaves = [];
            $temp = [];
            foreach($allLeaves as $allLeave){
                $temp = [
                    'date' => $allLeave,
                    'color'  => '#3341FF'
                ];
                array_push($formatAllLeaves,$temp);
            }
            array_push($formattedAllLeaves, $formatAllLeaves);
        }

        // Vacation leaves
        $vacationLeaves = Leave::where('user_id', $user_id)->where('status', 1)->where('leave_type', LeaveType::VACASION)->get();

        $allLeaves = [];
        $dates = [];

        if($vacationLeaves->isNotEmpty()){
            foreach($vacationLeaves as $leave){
    
                $startDateTime = DateTime::createFromFormat('Y-m-d H:i:s', $leave->start_date);
                $start = $startDateTime->format('Y-m-d');
                $endDateTime = DateTime::createFromFormat('Y-m-d H:i:s', $leave->end_date);
                $end = $endDateTime->format('Y-m-d');
    
                $start = new DateTime($start);
                $end = new DateTime($end);
    
                // create an iterateable period of date (P1D equates to 1 day)
                $period = new \DatePeriod($start, new \DateInterval('P1D'), $end);
    
                // best stored as array, so you can add more than one
                $holidays = array('2012-09-07');
    
                if($start<$end){
                    foreach($period as $dt) {
                        $curr = $dt->format('D');
        
                        // substract if Saturday or Sunday
                        if ($curr != 'Sat' || $curr != 'Sun') {
                            array_push($allLeaves, $dt->format('Y-m-d'));
                        }
        
                        // (optional) for the updated question
                        elseif (!in_array($dt->format('Y-m-d'), $holidays)) {
                            array_push($allLeaves, $dt->format('Y-m-d'));
                        }
                    }
                }else{
                    // Push set into parent array
                    array_push($allLeaves, $start->format('Y-m-d'));
                }
            }
    
            $formatAllLeaves = [];
            $temp = [];
            foreach($allLeaves as $allLeave){
                $temp = [
                    'date' => $allLeave,
                    'color'  => '#AB2438'
                ];
                array_push($formatAllLeaves,$temp);
            }
            array_push($formattedAllLeaves, $formatAllLeaves);
        }

        // Other leaves
        $otherLeaves = Leave::where('user_id', $user_id)->where('status', 1)->where('leave_type', LeaveType::OTHER)->get();

        $allLeaves = [];
        $dates = [];

        if($otherLeaves->isNotEmpty()){
            foreach($otherLeaves as $leave){
    
                $startDateTime = DateTime::createFromFormat('Y-m-d H:i:s', $leave->start_date);
                $start = $startDateTime->format('Y-m-d');
                $endDateTime = DateTime::createFromFormat('Y-m-d H:i:s', $leave->end_date);
                $end = $endDateTime->format('Y-m-d');
    
                $start = new DateTime($start);
                $end = new DateTime($end);
    
                // create an iterateable period of date (P1D equates to 1 day)
                $period = new \DatePeriod($start, new \DateInterval('P1D'), $end);
    
                // best stored as array, so you can add more than one
                $holidays = array('2012-09-07');
    
                if($start<$end){
                    foreach($period as $dt) {
                        $curr = $dt->format('D');
        
                        // substract if Saturday or Sunday
                        if ($curr != 'Sat' || $curr != 'Sun') {
                            array_push($allLeaves, $dt->format('Y-m-d'));
                        }
        
                        // (optional) for the updated question
                        elseif (!in_array($dt->format('Y-m-d'), $holidays)) {
                            array_push($allLeaves, $dt->format('Y-m-d'));
                        }
                    }
                }else{
                    // Push set into parent array
                    array_push($allLeaves, $start->format('Y-m-d'));
                }
            }
    
            $formatAllLeaves = [];
            $temp = [];
            foreach($allLeaves as $allLeave){
                $temp = [
                    'date' => $allLeave,
                    'color'  => '#277115'
                ];
                array_push($formatAllLeaves,$temp);
            }
            array_push($formattedAllLeaves, $formatAllLeaves);
        }

        // Special leaves
        $specialLeaves = Leave::where('user_id', $user_id)->where('status', 1)->where('leave_type', LeaveType::SPECIAL)->get();

        $allLeaves = [];
        $dates = [];

        if($specialLeaves->isNotEmpty()){
            foreach($specialLeaves as $leave){
    
                $startDateTime = DateTime::createFromFormat('Y-m-d H:i:s', $leave->start_date);
                $start = $startDateTime->format('Y-m-d');
                $endDateTime = DateTime::createFromFormat('Y-m-d H:i:s', $leave->end_date);
                $end = $endDateTime->format('Y-m-d');
    
                $start = new DateTime($start);
                $end = new DateTime($end);
    
                // create an iterateable period of date (P1D equates to 1 day)
                $period = new \DatePeriod($start, new \DateInterval('P1D'), $end);
    
                // best stored as array, so you can add more than one
                $holidays = array('2012-09-07');
    
                if($start<$end){
                    foreach($period as $dt) {
                        $curr = $dt->format('D');
        
                        // substract if Saturday or Sunday
                        if ($curr != 'Sat' || $curr != 'Sun') {
                            array_push($allLeaves, $dt->format('Y-m-d'));
                        }
        
                        // (optional) for the updated question
                        elseif (!in_array($dt->format('Y-m-d'), $holidays)) {
                            array_push($allLeaves, $dt->format('Y-m-d'));
                        }
                    }
                }else{
                    // Push set into parent array
                    array_push($allLeaves, $start->format('Y-m-d'));
                }
            }
    
            $formatAllLeaves = [];
            $temp = [];
            foreach($allLeaves as $allLeave){
                $temp = [
                    'date' => $allLeave,
                    'color'  => '#EFF21A'
                ];
                array_push($formatAllLeaves,$temp);
            }
            array_push($formattedAllLeaves, $formatAllLeaves);
        }

        // Short leaves
        $shortLeaves = Leave::where('user_id', $user_id)->where('status', 1)->where('leave_type', LeaveType::SHORT)->get();

        $allLeaves = [];
        $dates = [];

        if($shortLeaves->isNotEmpty()){
            foreach($shortLeaves as $shortLeave){
                $date = DateTime::createFromFormat('Y-m-d H:i:s', $shortLeave->start_date);
                array_push($allLeaves, $date->format('Y-m-d'));
            }

            $formatAllLeaves = [];
            $temp = [];
            foreach($allLeaves as $allLeave){
                $temp = [
                    'date' => $allLeave,
                    'color'  => '#1ACCF2'
                ];
                array_push($formatAllLeaves,$temp);
            }
            array_push($formattedAllLeaves, $formatAllLeaves);
        }

        // Holidays
        $holidays = Holiday::get();

        $allLeaves = [];
        $dates = [];

        if($holidays->isNotEmpty()){
            foreach($holidays as $holiday){
                $date = $holiday->date;
                array_push($allLeaves, $date);
            }

            $formatAllLeaves = [];
            $temp = [];
            foreach($allLeaves as $allLeave){
                $temp = [
                    'date' => $allLeave,
                    'title' => 'Holiday',
                    'color'  => '#FF0000'
                ];
                array_push($formatAllLeaves,$temp);
            }
            array_push($formattedAllLeaves, $formatAllLeaves);
        }

        return view('report.user_calendar', ['data' => $formattedAllLeaves, 'user_name' => $user_name->name]);
        
        // return response()->json([
        //     'states' => 200,
        //     'data' => $formattedAllLeaves
        // ]);
    }

    public function usersList(){
        $users = User::whereNotIn('user_type', [0,1,4])->get();
        return view('report.users_calendar_list', ['users' => $users]);
    }
}
