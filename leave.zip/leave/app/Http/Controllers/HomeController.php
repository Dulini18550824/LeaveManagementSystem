<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\LeaveType;
use App\UserLeave;
use App\Leave;
use Carbon\Carbon;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $user_leaves = UserLeave::where('user_id', \Auth::id())->get();
        $leaves = [
            'casual' => 0,
            'vacation' => 0,
            'short' => 0,
            'other' => 0,
            'special' => 0
        ];
        if($user_leaves != NULL){
            foreach($user_leaves as $user_leave){
                if($user_leave->leave_type == LeaveType::CASSUAL){
                    $leaves['casual'] = $user_leave->count;
                }
                if($user_leave->leave_type == LeaveType::VACASION){
                    $leaves['vacation'] = $user_leave->count;
                }
                if($user_leave->leave_type == LeaveType::SHORT){
                    $leaves['short'] = (int)$user_leave->count;
                }
                if($user_leave->leave_type == LeaveType::OTHER){
                    $leaves['other'] = (int)$user_leave->count;
                }
                if($user_leave->leave_type == LeaveType::SPECIAL){
                    $leaves['special'] = (int)$user_leave->count;
                }
            }
        }
        
        $leaves_status = Leave::where('user_id', \Auth::id())
        ->with('leaveType')->get();
        // dd($leaves_status);

        if (auth()->user()->is_acting == '2') {
            return view('home',['leaves' => $leaves, 'leaves_status' => $leaves_status])->with('acting_approval', 'true');
        }

        return view('home',['leaves' => $leaves, 'leaves_status' => $leaves_status]);
    }
}
