<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use App\Mail\ApprovedLeaveMail;
use App\Mail\RejectedLeaveMail;
use App\Mail\SpecialLeaveToRegistar;
use App\Mail\WarningMail;
use App\FileUpload;
use App\LeaveType;
use App\UserLeave;
use App\Holiday;
use App\Leave;
use App\User;
use DateTime;
use Carbon\Carbon;

class LeaveController extends Controller
{
    public function __construct() {
        
    }


    public function select(){
        $user_appointment_date = new Carbon(\Auth::user()->first_appointment);
        $today = Carbon::now();
        $diff =  $today->diffInMonths($user_appointment_date);
        $permanent = false;
        if($diff>9){
            $permanent = true;
        }
        return view('leave.select',['permanent' => $permanent]);
    }

    // View short leave form
    public function shortLeaveView($id=NULL){
        $leave = NULL;
        $count = 0;
        if($id != NULL){
            $leave = Leave::find($id);
            return view('leave.short',['count' => $count, 'leave' =>$leave]);
        }else{
            
            return view('leave.short', compact('count', 'leave'));

        }
    }

    // Save short leave
    public function shortLeave(Request $request){
        $validatedData = $request->validate([
            'start_date' => 'required',
            'reason' => 'required',
            'time_from' => 'required|before:time_to',
            'time_to' => 'required'
        ]);

        $start_datetime = new DateTime(date('Y-m-d').' '.$request->time_from);
        $end_datetime = new DateTime(date('Y-m-d').' '.$request->time_to);

        $time_diff = $start_datetime->diff($end_datetime);

        if($time_diff->format('%H days') > 1.5){
            return redirect()->back()->with('message', 'Seleceted time range is invalid.');
        }

        $leave_exist = array_key_exists('leave_id', $request->all());

        if($leave_exist){
            $leave = Leave::where('id', $request->leave_id)
            ->update([
                'reason' => $request->reason,
                'start_date' => $request->start_date,
                'end_date' => $request->start_date,
                'time_from' => $request->time_from,
                'time_to' => $request->time_to,
            ]);
            if($leave){
                return redirect()->back()->with('msg', 'Leave has updated.'); 
            }else{
                return redirect()->back()->with('message', 'Leave cannot update.');
            }
        }else{
            // Check user has already added this leave
            $leave_exist = Leave::where('user_id', \Auth::id())->where('start_date',$request->start_date)->get();
            
            if($leave_exist->isNotEmpty()){;
                return redirect()->back()->with('message', 'Already have a leave on selected date');
            }else{
                $startdate = new Carbon($request->start_date);
                $leave = $this->getUsershortLeaveCountByMonth($startdate->month);
                if($leave != NULL && $leave->count < 2){
                    $result = $this->inserLeaveRecord(LeaveType::SHORT, NULL, $request->reason , $request->start_date, $request->start_date, $request->time_from, $request->time_to, NULL, NULL);
                    if($result){
                        return redirect('/leave/select')->with('msg', 'Leave has sent for the approval.');
                    }else{
                        
                        return redirect()->back()->with('message', 'Something went wrong!!!.');
                    }
                }else if ($leave != NULL && $leave->count >= 2) {
                    return redirect()->back()->with('message', 'You have exceed the maximum number of short leaves');
                }else{
                    $result = $this->inserLeaveRecord(LeaveType::SHORT, NULL, $request->reason, $request->start_date, $request->start_date, $request->time_from, $request->time_to, NULL, NULL);

                    if($result){
                        return redirect()->back()->with('msg', 'Leave has sent for the approval.');
                    }else{
                        return redirect()->back()->with('message', 'Something went wrong!!!.');
                    }
                } 
            }
            
        }


    }

    // View normal leave form
    public function normalLeaveView($id=NULL){
        $leave = NULL;
        if($id != NULL){
            $leave = Leave::with('acting')->find($id);
        }
        $team = \Auth::user()->team;
        $users = User::where('team_id',$team->id)->where('id', '!=', \Auth::id())->get();
        $holidays = Holiday::select('date')->get()->toArray();

        $leave_types = LeaveType::get();
        $earned_leave = NULL;

        // Check permenent
        $user_appointment_date = new Carbon(\Auth::user()->first_appointment);
        $today = Carbon::now();
        $diff =  $today->diffInMonths($user_appointment_date);
        $permanent = false;
        if($diff>9){
            $permanent = true;
        }

        // If permenent false calculate available leaves
        if($permanent == false){
            $no_of_leaves = $diff * 1.5;
            // Check already taken leave
            $user_leave = UserLeave::where('user_id', \Auth::id())->where('leave_type', LeaveType::CASSUAL)->first();
            if($user_leave == NULL){
                $earned_leave = $no_of_leaves;
            }else{
                $earned_leave = $no_of_leaves - $user_leave->count;
            }

        }
        return view('leave.normal',['users'=>$users, 'leave_types' => $leave_types, 'leave' => $leave, 'earned_leave' => $earned_leave, 'holidays' => $holidays]);
    }



    // Save normal leave
    public function normalLeave(Request $request){
        $validatedData = $request->validate([
            'no_of_days' => 'required',
            'reason' => 'required',
            'start_date' => 'required|before_or_equal:end_date',
            'end_date' => 'required',
            'acting_user_id' => 'required',
        ]);
        
        //------acting user leave validation------
        $user_leaves = Leave::where('user_id', $request->input('acting_user_id'))->get();
        $carbon_start_date = new Carbon($request->input('start_date'));
        $carbon_end_date = new Carbon($request->input('end_date'));
        $leaves_filter = $user_leaves->filter(function($item) use ($carbon_start_date, $carbon_end_date) {
            if ($carbon_start_date->between($item->start_date, $item->end_date) || $carbon_end_date->between($item->start_date, $item->end_date)) {
                return $item;
            }
        });

        if ($leaves_filter->count() > 0) {
            return redirect()->back()->with('message', $user_leaves->first()->user->name . " has leave on this day");
        }
        //-------------------------------------------
        
        // Create file name
        $fileName = NULL;
        if($request->file_upload != NULL){
            $fileName = Carbon::now()->timestamp.'.'.$request->file_upload->getClientOriginalExtension();
        }
        $leave_exist = array_key_exists('leave_id', $request->all());
        
        if($leave_exist){
            $check_leave_file = Leave::find($request->leave_id);
            if($check_leave_file->file_upload != NULL && $request->file_upload == NULL){
                $fileName = $check_leave_file->file_upload;
            }
            
            $leave = Leave::where('id', $request->leave_id)
            ->update([
                'no_of_days' => $request->no_of_days,
                'reason' => $request->reason,
                'start_date' => $request->start_date,
                'end_date' => $request->end_date,
                'file_upload' => $fileName,
                'acting_user_id' => $request->acting_user_id,
            ]);

            if($request->file_upload != NULL){
                $request->file_upload->move(public_path('uploads'), $fileName);
            }

            if($leave){
                return redirect()->back()->with('msg', 'Leave has updated.'); 
            }else{
                return redirect()->back()->with('message', 'Leave cannot update.');
            }
        }else{
            // Check user has already added this leave
        //$leave_exist = Leave::where('user_id', \Auth::id())->where('start_date',$request->input('start_date'))->where('end_date',$request->input('end_date'))->get();
        $leave_exist = Leave::where('user_id', \Auth::id())->where('start_date',$request->start_date)->where('end_date',$request->end_date)->get();
        //---------------chcek user has short leave
        $leave_allowed = Leave::where('user_id', \Auth::id())->where('start_date',$request->start_date)->where('end_date',$request->end_date)->where('leave_type', LeaveType::SHORT)->get();

    
        if($leave_exist->isNotEmpty()){
            return redirect()->back()->with('message', 'Already have a leave on selected date');
        } else if ($leave_allowed->isNotEmpty()) {
            return redirect()->back()->with('message', 'You have short leave on this day');
        //--------------------------------------
        
            }else{
                // For probationary employees
                // Check permenent
                $user_appointment_date = new Carbon(\Auth::user()->first_appointment);
                $today = Carbon::now();
                $diff =  $today->diffInMonths($user_appointment_date);
                $permanent = false;
                if($diff>9){
                    $permanent = true;
                }

                // If permenent false calculate available leaves
                if($permanent == false){
                    $no_of_leaves = $diff * 1.5;
                    //return response()->json($no_of_leaves);

                    // Check already taken leave
                    $user_leave = UserLeave::where('user_id', \Auth::id())->where('leave_type', LeaveType::CASSUAL)->first();
                    if($user_leave == NULL){
                        $earned_leave = $no_of_leaves;
                    }else{
                        $earned_leave = $no_of_leaves - $user_leave->count;
                    }
                    if($request->no_of_days > $earned_leave){
                        return redirect()->back()->with('message', 'You do not have enough leave balance.');
                    }else{
                        if($user_leave == NULL){
                            $result = UserLeave::create([
                                'user_id' => \Auth::id(),
                                'year' => Carbon::now()->year,
                                'leave_type' => LeaveType::CASSUAL,
                                'count' => $request->no_of_days
                            ]);
                        }else{
                            $result = UserLeave::where('user_id', \Auth::id())
                                    ->where('leave_type', LeaveType::CASSUAL)
                                    ->update(['count' => $user_leave->count+$request->no_of_days]);
                        }
                    }
                }

                // Check file has uploaded when no_of_days > 3
                if($request->no_of_days > 3 && $request->file_upload == NULL){
                    return redirect()->back()->with('message', 'File Upload field cannot be empty.');
                }
                
                $cassual_count = 0;
                $vacation_count = 0;
        
                // Get user's current cassual leave balance
                $user_cassual_leaves = UserLeave::where('user_id', \Auth::id())
                                ->where('leave_type', LeaveType::CASSUAL)
                                ->where('year', Carbon::now()->year)->first();
        
                // Get user's current vacation leave balance
                $user_vacation_leaves = UserLeave::where('user_id', \Auth::id())
                                ->where('leave_type', LeaveType::VACASION)
                                ->where('year', Carbon::now()->year)->first();

                $total_c = $request->input('no_of_days');
                if ($user_cassual_leaves != NULL) {
                    $total_c = $total_c + $user_cassual_leaves->count;
                }
                
                if ($user_vacation_leaves != NULL) {
                    $total_c = $total_c + $user_vacation_leaves->count;
                }

                if ($total_c > 45) {
                    return redirect()->back()->with('message', 'You have reached maximum amout of leaves of 45.'); 
                }
      
        
                // Separate annual and cassual counts
                if($request->no_of_days <= 6){
                    $cassual_count = $request->no_of_days;
                }else{
                    $cassual_count = 6;
                    $vacation_count = $request->no_of_days - 6;
                }
        
                // Leave insertion logics
                $result = NULL;
                // Check user have not any applied cassual leaves and applying leave count is < 6 
                if($user_cassual_leaves == NULL && $cassual_count <= 6){
                    $result = $this->inserLeaveRecord(LeaveType::CASSUAL, $request->no_of_days, $request->reason, $request->start_date, $request->end_date, NULL, NULL, $fileName, $request->acting_user_id);
                    // Check user have not any applied cassual leaves and applying leave count is > 6
                }elseif($user_cassual_leaves == NULL && $cassual_count > 6){
                    // Check user have not any applied vacation leaves
                    if($user_vacation_leaves == NULL){
                        $result = $this->inserLeaveRecord(LeaveType::CASSUAL, $request->no_of_days, $request->reason, $request->start_date, $request->end_date, NULL, NULL, $fileName, $request->acting_user_id);
                    // Check user have any applied vacation leaves and have enough leave balance
                    }elseif($user_vacation_leaves != NULL && $user_vacation_leaves->count + $vacation_count <= 24){
                        $result = $this->inserLeaveRecord(LeaveType::CASSUAL, $request->no_of_days, $request->reason, $request->start_date, $request->end_date, NULL, NULL, $fileName, $request->acting_user_id);
                    }else{
                        return redirect()->back()->with('message', 'You do not have enough leave balance.'); 
                    }
                // Check user have any applied cassual leaves and applying leave count is < 6 
                }elseif($user_cassual_leaves != NULL && $cassual_count <= 6){
                    // Check user have enough cassual leave balance
                    if($user_cassual_leaves->count + $cassual_count <= 21){
                        $result = $this->inserLeaveRecord(LeaveType::CASSUAL, $request->no_of_days, $request->reason, $request->start_date, $request->end_date, NULL, NULL, $fileName, $request->acting_user_id);
                    // Check user have not applied any vacation leaves
                    }elseif($user_vacation_leaves == NULL){
                        $result = $this->inserLeaveRecord(LeaveType::VACASION, $request->no_of_days, $request->reason, $request->start_date, $request->end_date, NULL, NULL, $fileName, $request->acting_user_id);
                    // Check user have enough vacation leave balance
                    }elseif($user_vacation_leaves != NULL && $user_vacation_leaves->count + $cassual_count <= 24){
                        $result = $this->inserLeaveRecord(LeaveType::VACASION, $request->no_of_days, $request->reason, $request->start_date, $request->end_date, NULL, NULL, $fileName, $request->acting_user_id);
                    }else{
                        return redirect()->back()->with('message', 'You do not have enough leave balance.'); 
                    }
                // Check user have any applied cassual leaves and applying leave count is > 6
                }elseif($user_cassual_leaves != NULL && $cassual_count > 6){
                    // Check user have enough cassual and vacation leave balance
                    if($user_cassual_leaves->count + $cassual_count <= 21 && $user_vacation_leaves != NULL
                    || $user_cassual_leaves->count + $cassual_count <= 21 && $user_vacation_leaves->count + $vacation_count <= 24){
                        $result = $this->inserLeaveRecord(LeaveType::CASSUAL, $request->no_of_days, $request->reason, $request->start_date, $request->end_date, NULL, NULL, $fileName, $request->acting_user_id);
                    // Check user have enough vacation leave balance
                    }elseif($user_vacation_leaves->count + $request->no_of_days <= 24){
                        $result = $this->inserLeaveRecord(LeaveType::VACASION, $request->no_of_days, $request->reason, $request->start_date, $request->end_date, NULL, NULL, $fileName, $request->acting_user_id);
                    }else{
                        return redirect()->back()->with('message', 'You do not have enough leave balance.'); 
                    }
                }
        
                if($result){
                    if($request->file_upload != NULL){
                        $request->file_upload->move(public_path('uploads'), $fileName);
                    }

                    return redirect()->back()->with('msg', 'Leave has sent for the approval.'); 
                }

            }

        }
    }

    public function specialLeaveView($id=NULL){
        $leave = NULL;
        if($id != NULL){
            $leave = Leave::with('fileUploads')->find($id);
        }
        $holidays = Holiday::select('date')->get()->toArray();

        return view('leave.special',['leave' => $leave, 'holidays' => $holidays]);
    }

    public function specialLeave(Request $request){
        
        // Create file name
        $fileName = NULL;
        if($request->request_letter != NULL){
            $fileName = Carbon::now()->timestamp.'.'.$request->request_letter->getClientOriginalExtension();
        }

        $leave_exist = array_key_exists('leave_id', $request->all());

        if($leave_exist){
            $validatedData = $request->validate([
                'no_of_days' => 'required',
                'reason' => 'required',
                'start_date' => 'required|before_or_equal:end_date',
                'end_date' => 'required'
            ]);

            $leave = Leave::where('id', $request->leave_id)
            ->update([
                'no_of_days' => $request->no_of_days,
                'reason' => $request->reason,
                'start_date' => $request->start_date,
                'end_date' => $request->end_date,
            ]);

            if($request->request_letter != NULL){
                Leave::where('id', $request->leave_id)->update(['file_upload' => '/uploads/'.$fileName]);
                $request->request_letter->move(public_path('uploads'), $fileName);
            }

            if($request->other_files[0] != NULL){
                $files = FileUpload::where('leave_id', $request->leave_id)->get()->pluck('id')->toArray();
                FileUpload::destroy($files);
                foreach($request->other_files as $other_file){
                    $other_file_name = Carbon::now()->timestamp.rand().'.'.$other_file->getClientOriginalExtension();
                    FileUpload::create([
                        'leave_id' => $request->leave_id,
                        'file_name' => $other_file_name,
                        'location' => '/uploads/'.$other_file_name
                    ]);
                    $other_file->move(public_path('uploads'), $other_file_name);
                    $other_file_name = NULL;
                }
            }
            if($leave){
                return redirect()->back()->with('msg', 'Leave has updated.'); 
            }else{
                return redirect()->back()->with('message', 'Leave cannot update.');
            }
        }else{
            $validatedData = $request->validate([
                'no_of_days' => 'required',
                'reason' => 'required',
                'start_date' => 'required|before_or_equal:end_date',
                'end_date' => 'required',
                'request_letter' => 'required',
                'other_files' => 'required'
            ]);

            // Check user has already added this leave
            $leave_exist = Leave::where('user_id', \Auth::id())->where('start_date',$request->start_date)->where('end_date',$request->end_date)->get();
            $leave_allowed = Leave::where('user_id', \Auth::id())->where('start_date',$request->start_date)->where('end_date',$request->end_date)->where('leave_type', LeaveType::SHORT)->get();

            if($leave_exist->isNotEmpty()){
                return redirect()->back()->with('message', 'Already have a leave on selected date');
            } else if ($leave_allowed->isNotEmpty()) {
                return redirect()->back()->with('message', 'You have short leave on this day');
            }else{
                $result = $this->inserLeaveRecord(LeaveType::SPECIAL, $request->no_of_days, $request->reason, $request->start_date, $request->end_date, NULL, NULL, $fileName, NULL);
            
            if($result){
                $request->request_letter->move(public_path('uploads'), $fileName);
                foreach($request->other_files as $other_file){
                    $other_file_name = Carbon::now()->timestamp.rand().'.'.$other_file->getClientOriginalExtension();
                    FileUpload::create([
                        'leave_id' => $result->id,
                        'file_name' => $other_file_name,
                        'location' => '/uploads/'.$other_file_name
                    ]);
                    $other_file->move(public_path('uploads'), $other_file_name);
                    $other_file_name = NULL;
                }
                Mail::to('reg@kdu.ac.lk')->send(new SpecialLeaveToRegistar());
                return redirect()->back()->with('msg', 'Leave has sent for the approval.'); 
            }else{
                return redirect()->back()->with('message', 'Leave has not sent.'); 
            }
            }
        }
    }

    public function otherLeaveView($id=NULL){
        $leave = NULL;
        if($id != NULL){
            $leave = Leave::with('fileUploads')->find($id);
        }
        $holidays = Holiday::select('date')->get()->toArray();

        return view('leave.other',['leave' => $leave, 'holidays' => $holidays]);
    }

    public function otherLeave(Request $request){
        $validatedData = $request->validate([
            'no_of_days' => 'required',
            'reason' => 'required',
            'start_date' => 'required|before_or_equal:end_date',
            'end_date' => 'required'
        ]);

         // Check user has already added this leave
         $leave_exist = Leave::where('user_id', \Auth::id())->where('start_date',$request->start_date)->where('end_date',$request->end_date)->get();
         $leave_allowed = Leave::where('user_id', \Auth::id())->where('start_date', $request->start_date)->where('end_date', $request->end_date)->where('leave_type', LeaveType::SHORT)->get();
        
         if($leave_exist->isNotEmpty()){
             return redirect()->back()->with('message', 'Already have a leave on selected date');
        } else if ($leave_allowed->isNotEmpty()) {
                return redirect()->back()->with('message', 'You have short leave on this day');
         }else{
            $leave_exist = array_key_exists('leave_id', $request->all());
        if($leave_exist){
            $leave = Leave::where('id', $request->leave_id)
            ->update([
                'no_of_days' => $request->no_of_days,
                'reason' => $request->reason,
                'start_date' => $request->start_date,
                'end_date' => $request->end_date,
            ]);

            if($leave){
                return redirect()->back()->with('msg', 'Leave has updated.'); 
            }else{
                return redirect()->back()->with('message', 'Leave cannot update.');
            }

            }else{
                $result = $this->inserLeaveRecord(LeaveType::OTHER, $request->no_of_days, $request->reason, $request->start_date, $request->end_date, NULL, NULL, NULL, NULL);
                if($result){
                    return redirect()->back()->with('msg', 'Leave has sent for the approval.'); 
                }else{
                    return redirect()->back()->with('message', 'Leave has not sent.'); 
                }
            }
         }

        
    }


    // Show pending leave requests
    public function manageLeaveView(){
        $leaves = NULL;
        $auth_user = User::where('id', auth()->user()->id)->first();
        $user_type = '';
        //return response()->json(auth()->user()->user_type);

        if (auth()->user()->user_type === User::TYPE_REGISTAR) {
            $leaves = Leave::where('status', 3)->where('user_id', '!=', \Auth::id())->with('user','acting', 'fileUploads')->get();
            $user_type = "REGISTAR";
        } else if (auth()->user()->user_type === User::TYPE_HOD || auth()->user()->is_acting === 1) {
            $leaves = Leave::where('status', 0)->where('user_id', '!=', \Auth::id())->with('user','acting', 'fileUploads')->get();
            $user_type = "HOD";
        }
        //return response()->json($user_type);
        return view('leave.manage', compact('leaves', 'auth_user', 'user_type'));
    }

    // Edit leave
    public function editLeaveView($type){
        $leaves = Leave::where('leave_type', $type)->where('status', 0)->where('user_id', \Auth::id())->with('user','acting')->get();
        // dd($leaves);
        return view('leave.edit', ['leaves' => $leaves]);
    }

    // Approve leave requests
    public function approveLeave($id){
        $leave = Leave::where('id', $id)->with('user')->first();
        $year = Carbon::createFromFormat('Y-m-d H:i:s', $leave->start_date)->format('Y');
        $month = Carbon::createFromFormat('Y-m-d H:i:s', $leave->end_date)->format('m');
        $leave_balance = $this->getUserLeaveCount($leave->user_id,$year,$leave->leave_type, $month);
        $result = NULL;
        
        // Approve other leaves
        if($leave->leave_type == LeaveType::OTHER){
            $result = $this->inserUserLeaveRecord($leave->user_id,$year,$month,$leave->leave_type, $leave->no_of_days);
        }elseif($leave->leave_type == LeaveType::SPECIAL){
            $result = $this->inserUserLeaveRecord($leave->user_id,$year,$month,$leave->leave_type, $leave->no_of_days);
        }else{
            // Check leave balalnce before approve
            if($leave_balance != NULL){
                if($leave->leave_type == LeaveType::SHORT && $leave_balance->count <2){
                    $result = $this->inserUserLeaveRecord($leave->user_id,$year,$month,$leave->leave_type, NULL);
                }elseif($leave->leave_type == LeaveType::CASSUAL || $leave->leave_type == LeaveType::VACASION){
                    $result = $this->inserUserLeaveRecord($leave->user_id,$year,$month,$leave->leave_type, $leave->no_of_days);
                }else{
                    return response()->json([
                        'states' => 1001,
                        'data' => 'This employee doesn\'t have enought leave balance'
                    ]);
                }
            }else{
                if($leave->leave_type == LeaveType::SHORT){
                    $result = $this->inserUserLeaveRecord($leave->user_id,$year,$month,$leave->leave_type, NULL);
                }elseif($leave->leave_type == LeaveType::CASSUAL || $leave->leave_type == LeaveType::VACASION){
                    $result = $this->inserUserLeaveRecord($leave->user_id,$year,$month,$leave->leave_type, $leave->no_of_days);
                }
            }
        }
        if($result == 200){
            Leave::where('id', $id)->update([
                'status' => Leave::APPROVED,
                'approved_at' => Carbon::now()
            ]);

            $data = array(
                'name' => $leave->user->name,
                'date' => $leave->start_date->format('Y-m-d')
            );

            Mail::to($leave->user->email)->send(new ApprovedLeaveMail($data));

            return response()->json([
                'states' => 200,
                'data' => $result
            ]);
        }elseif($result == 1000){
            return response()->json([
                'states' => 1000,
                'data' => 'Something went wrong'
            ]);
        }elseif($result == 1001){
            return response()->json([
                'states' => 1001,
                'data' => 'This employee doesn\'t have enought leave balance'
            ]);
        }else{
            return response()->json([
                'states' => 1000,
                'data' => 'Something went wrong'
            ]);
        }
    }

    public function inserUserLeaveRecord($user_id, $year, $month, $leave_type, $no_of_days){
        // Add user's other leaves
        if($leave_type == LeaveType::OTHER){
            $result = \DB::table('user_leaves')->where('user_id', $user_id)
            ->where('leave_type', $leave_type)
            ->where('year', $year)->first();
            if($result == NULL){
                $result = \DB::table('user_leaves')->insert(
                    [
                        'user_id' => $user_id, 
                        'year' => $year,
                        'leave_type' => $leave_type,
                        'count' => $no_of_days
                    ]);
                if($result){
                    return $result;
                }else{
                    return 1000;
                }
            }else{
                $result = \DB::table('user_leaves')
                ->where('user_id', $user_id)
                ->where('leave_type', $leave_type)
                ->where('year', $year)
                ->update(['count' => $result->count+$no_of_days]);

                if($result){
                    return 200;
                }else{
                    return 1000;
                }
            }

        } elseif($leave_type == LeaveType::SPECIAL){
            $result = \DB::table('user_leaves')->where('user_id', $user_id)
            ->where('leave_type', $leave_type)
            ->where('year', $year)->first();
            if($result == NULL){
                $result = \DB::table('user_leaves')->insert(
                    [
                        'user_id' => $user_id, 
                        'year' => $year,
                        'leave_type' => $leave_type,
                        'count' => $no_of_days
                    ]);
                if($result){
                    return $result;
                }else{
                    return 1000;
                }
            }else{
                $result = \DB::table('user_leaves')
                ->where('user_id', $user_id)
                ->where('leave_type', $leave_type)
                ->where('year', $year)
                ->update(['count' => $result->count+$no_of_days]);

                if($result){
                    return 200;
                }else{
                    return 1000;
                }
            }
        }
        // Add user's short leave
        elseif($leave_type == LeaveType::SHORT){
            $result = \DB::table('user_leaves')->where('user_id', $user_id)
                        ->where('leave_type', $leave_type)
                        ->where('year', $year)->where('month', $month)->first();
            if($result == null){
                $result = \DB::table('user_leaves')->insert(
                    [
                        'user_id' => $user_id, 
                        'year' => $year,
                        'month' => $month,
                        'leave_type' => $leave_type,
                        'count' => 1
                    ]);
                if($result){
                    return 200;
                }else{
                    return 1000;
                }
            }elseif($result->count < 2){
                $result = \DB::table('user_leaves')
                ->where('user_id', $user_id)
                ->where('leave_type', $leave_type)
                ->where('year', $year)
                ->where('month', $month)
                ->update(['count' => $result->count+1]);

                if($result){
                    return 200;
                    // response()->json([
                    //     'states' => 200,
                    //     'data' => $result
                    // ]);
                }return 1000;
                // response()->json([
                //     'states' => 1000,
                //     'data' => 'Something went wrong'
                // ]);
            }else{
                return 1001;
                // response()->json([
                //     'states' => 1001,
                //     'data' => 'This employee doesn\'t have enought leave balance'
                // ]); 
            }

        // Add user's full/half leave
        }elseif($leave_type == LeaveType::CASSUAL ||$leave_type == LeaveType::VACASION){
            $result = UserLeave::where('user_id', $user_id)
            ->where('leave_type', $leave_type)
            ->where('year', $year)->first();
            
            if($result == null){
                // If number of days < 6 or eaveType == CASSUAL
                if($no_of_days <= 6 && $leave_type == LeaveType::CASSUAL){
                    $create_result = NULL;
                    $create_result = UserLeave::create(
                        [
                            'user_id' => $user_id, 
                            'year' => $year,
                            'month' => $month,
                            'leave_type' => $leave_type,
                            'count' => $no_of_days
                        ]);
                        if($create_result){
                            return 200;
                        }else{
                            return 1001;
                        }
                // If number of days > 6   
                }elseif($no_of_days > 6){
                    
                    $vacation_result = UserLeave::where('user_id', $user_id)
                            ->where('leave_type', LeaveType::VACASION)
                            ->where('year', $year)->first();
                    if($vacation_result == NULL){
                        $create_result = UserLeave::create(
                            [
                                'user_id' => $user_id, 
                                'year' => $year,
                                'month' => $month,
                                'leave_type' => LeaveType::CASSUAL,
                                'count' => 6
                            ]);

                        $create_result2 = UserLeave::create(
                            [
                                'user_id' => $user_id, 
                                'year' => $year,
                                'month' => $month,
                                'leave_type' => LeaveType::VACASION,
                                'count' => $no_of_days - 6
                            ]);
                            if($create_result){
                                return 200;
                            }else{
                                return 1001;
                            }
                    }elseif($vacation_result->count + ($no_of_days - 6) <= 24){
                        $create_result = UserLeave::create(
                            [
                                'user_id' => $user_id, 
                                'year' => $year,
                                'month' => $month,
                                'leave_type' => LeaveType::CASSUAL,
                                'count' => 6
                            ]);
                        
                            $create_result =  UserLeave::where('user_id', $user_id)
                            ->where('leave_type', $leave_type)
                            ->where('year', $year)
                            ->where('month', $month)
                            ->update(['count' => $vacation_result->count + ($no_of_days - 6)]);
                            if($create_result){
                                return 200;
                            }else{
                                return 1001;
                            }
                    }else {
                        return 1001;
                        // response()->json([
                        //     'states' => 1001,
                        //     'data' => 'This employee doesn\'t have enought leave balance'
                        // ]); 
                    }
                }

                if($create_result){
                    return response()->json([
                        'states' => 200,
                        'data' => $create_result
                    ]);
                }
            }else{
                $update_result = NULL;
                if($leave_type == LeaveType::CASSUAL && $no_of_days <= 6 && $result->count+$no_of_days <= 21){
                    $update_result =  UserLeave::where('user_id', $user_id)
                            ->where('leave_type', $leave_type)
                            ->where('year', $year)
                            ->update(['count' => $result->count + $no_of_days]);
                }elseif($leave_type == LeaveType::CASSUAL && $no_of_days > 6 && $result->count+6 <= 21){
                    $vacation_result = UserLeave::where('user_id', $user_id)
                            ->where('leave_type', LeaveType::VACASION)
                            ->where('year', $year)->first();
                    if($vacation_result == NULL){
                        $update_result =  UserLeave::where('user_id', $user_id)
                            ->where('leave_type', $leave_type)
                            ->where('year', $year)
                            ->update(['count' => $result->count + 6]);

                        UserLeave::create(
                        [
                            'user_id' => $user_id, 
                            'year' => $year,
                            'month' => $month,
                            'leave_type' =>  LeaveType::VACASION,
                            'count' => $no_of_days - 6
                        ]);
                    }elseif($vacation_result->count + ($no_of_days - 6) <= 24){
                        $update_result =  UserLeave::where('user_id', $user_id)
                            ->where('leave_type', $leave_type)
                            ->where('year', $year)
                            ->update(['count' => $vacation_result->count + 6]);

                            UserLeave::where('user_id', $user_id)
                            ->where('leave_type', LeaveType::VACASION)
                            ->where('year', $year)
                            ->update(['count' => $vacation_result->count + ($no_of_days - 6)]);
                    }
                }elseif($leave_type == LeaveType::VACASION){
                    $casual_result = UserLeave::where('user_id', $user_id)
                        ->where('leave_type', LeaveType::CASSUAL)
                        ->where('year', $year)->first();

                    $vacasion_result = UserLeave::where('user_id', $user_id)
                        ->where('leave_type', LeaveType::VACASION)
                        ->where('year', $year)->first();

                    $remain_casual_count = 21 - $casual_result->count;

                    if($remain_casual_count > 0){
                        $cas_count = $remain_casual_count;
                        $vac_count = $no_of_days - $remain_casual_count;

                        if($vacasion_result == NULL){
                            $update_result =  UserLeave::where('user_id', $user_id)
                            ->where('leave_type', LeaveType::CASSUAL)
                            ->where('year', $year)
                            ->update(['count' => $casual_result->count + $cas_count]);

                            UserLeave::create(
                                [
                                    'user_id' => $user_id, 
                                    'year' => $year,
                                    'leave_type' =>  LeaveType::VACASION,
                                    'count' => $vac_count
                                ]);
                            return 200;
                        }else{
                            if($vacasion_result->count + $vac_count <= 24){
                                $update_result =  UserLeave::where('user_id', $user_id)
                                    ->where('leave_type', LeaveType::CASSUAL)
                                    ->where('year', $year)
                                    ->update(['count' => $casual_result->count + $cas_count]);

                                $update_result =  UserLeave::where('user_id', $user_id)
                                    ->where('leave_type', LeaveType::VACASION)
                                    ->where('year', $year)
                                    ->update(['count' => $vacasion_result->count + $vac_count]);

                                return 200;
                            }else {
                                return 1001;
                            }
                        }

                    }else{
                        if($vacasion_result == NULL){
                            UserLeave::create(
                                [
                                    'user_id' => $user_id, 
                                    'year' => $year,
                                    'leave_type' =>  LeaveType::VACASION,
                                    'count' => $no_of_days
                                ]);
                            return 200;
                        }else{
                            if($vacasion_result->count + $no_of_days <= 24){
                                $update_result =  UserLeave::where('user_id', $user_id)
                                    ->where('leave_type', LeaveType::VACASION)
                                    ->where('year', $year)
                                    ->update(['count' => $vacasion_result->count + $no_of_days]);

                                return 200;
                            }else {
                                return 1001;
                            }
                        }
                    }
                }
                if($update_result){
                    return 200;
                }else {
                    return 1001;
                }
            }
        }
    }

    // Reject leave requests
    public function rejectLeave($id){
        $leave = Leave::where('id', $id)->with('user')->first();
        $result = Leave::where('id', $id)->update(['status' => Leave::REJECTED]);

        $data = array(
            'name' => $leave->user->name,
            'date' => $leave->start_date->format('Y-m-d')
        );

        Mail::to($leave->user->email)->send(new RejectedLeaveMail($data));

        if($result){
            return response()->json([
                'states' => 200,
                'data' => 'Leave request rejected successfully'
            ]);
        }else{
            return response()->json([
                'states' => 1000,
                'data' => 'Something went wron!'
            ]);
        }
    }

    // Get user leave count
    public function getUserLeaveCount($user_id, $year, $leave_type, $month = NULL){
        $leaves = NULL;
        if($leave_type == LeaveType::SHORT){
            $leaves = UserLeave::where('user_id', $user_id)->where('year', $year)
                    ->where('month', $month)->where('leave_type', $leave_type)->first();
        }else{
            $leaves = UserLeave::where('user_id', $user_id)->where('year', $year)
                    ->where('leave_type', $leave_type)->first();
        }
        return $leaves;
    }

    // Get auth user short leave count
    public function getUsershortLeaveCount(){
        $leaves = \DB::table('user_leaves')->where('user_id', \Auth::id())->where('year', Carbon::now()->year)
                ->where('month', Carbon::now()->month)->where('leave_type', LeaveType::SHORT)->first();
        return $leaves;
    }

    public function getUsershortLeaveCountByMonth($month){
        $leaves = \DB::table('user_leaves')->where('user_id', \Auth::id())->where('year', Carbon::now()->year)
                ->where('month', $month)->where('leave_type', LeaveType::SHORT)->first();
        return $leaves;
    }

    public function inserLeaveRecord($leave_type=NULL, $no_of_days=NULL, $reason=NULL, $start_date=NULL, $end_date=NULL, $time_from=NULL, $time_to=NULL, $file_upload=NULL, $acting_user_id=NULL){
        $result = Leave::create([
            'user_id' => \Auth::id(),
            'leave_type' => $leave_type,
            'no_of_days' => $no_of_days,
            'reason' => $reason,
            'start_date' => $start_date,
            'end_date' => $end_date,
            'time_from' => $time_from,
            'time_to' => $time_to,
            'file_upload' => $file_upload != NULL ? '/uploads/'.$file_upload : NULL,
            'acting_user_id' => $acting_user_id
        ]);

        return $result;
    }

    public function deleteLeave($id){
        $leave_id = Leave::find($id);
        $files = FileUpload::where('leave_id', $leave_id->id)->delete();
        $result = Leave::destroy($id);
        if($result){
            return redirect()->back()->with('msg', 'Leave has deleted.'); 
        }else{
            return redirect()->back()->with('message', 'Leave cannot delete.');
        }
    }

    public function sendWarningMail($user_id){
        $user = User::find($user_id);
        $result = Mail::to($user->email)->send(new WarningMail());
        if(count(Mail::failures()) > 0){
            return response()->json([
                'status' => 1001,
                'data' => 'Warning Mail Not Sent'
            ]);
        }else{
            return response()->json([
                'status' => 200,
                'data' => 'Warning Mail Sent'
            ]);
        }
    }

    public function forwardLeave($leave_id) {
        $leave = Leave::where('id', $leave_id)->firstOrFail();
        $leave->update(['status' => 3]);
        
        return response()->json([
            'status' => 200,
            'data' => "Request Forwarded",
        ]);
    }

}
