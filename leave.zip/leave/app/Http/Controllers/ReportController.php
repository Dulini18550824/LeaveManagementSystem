<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Leave;
use App\LeaveType;
use App\UserLeave;
use Carbon\Carbon;
use App\Holiday;

class ReportController extends Controller
{
    public function index(){
        return view('report.select');
    }

    public function leaveDetail($id=NULL){
        if($id != NULL){
            $user = User::where('id',$id)->with('team')->first();
            $leaves = Leave::where('user_id', $id)
                    ->whereYear('start_date', Carbon::now()->year)
                    ->where('leave_type', '!=', LeaveType::SHORT)
                    ->where('status', Leave::APPROVED)
                    ->with('leaveType')->get();
        }else{
            $user = User::where('id',\Auth::id())->with('team')->first();
            $leaves = Leave::where('user_id', \Auth::id())
                    ->whereYear('start_date', Carbon::now()->year)
                    ->where('leave_type', '!=', LeaveType::SHORT)
                    ->where('status', Leave::APPROVED)
                    ->with('leaveType')->get();
        }
        return view('report.leave_detail', ['user' => $user, 'leaves' => $leaves, 'id'=> $id]);
    }

    public function shortLeaveDetail($id=NULL){
        if($id != NULL){
            $user = User::where('id',$id)->with('team')->first();
            $leaves = Leave::where('user_id', $id)
                    ->whereYear('start_date', Carbon::now()->year)
                    ->where('leave_type', LeaveType::SHORT)
                    ->where('status', Leave::APPROVED)
                    ->with('leaveType')->get();
        }else{
            $user = User::where('id',\Auth::id())->with('team')->first();
            $leaves = Leave::where('user_id', \Auth::id())
                    ->whereYear('start_date', Carbon::now()->year)
                    ->where('leave_type', LeaveType::SHORT)
                    ->where('status', Leave::APPROVED)
                    ->with('leaveType')->get();
        }
        return view('report.short_leave_detail', ['user' => $user, 'leaves' => $leaves, 'id'=> $id]);
    }

    public function BalanceLeave(){
        $user = User::where('id',\Auth::id())->with('team')->first();

        $user_leaves = UserLeave::where('user_id', \Auth::id())->get();
        $leaves = [
            'casual' => 0,
            'vacation' => 0,
        ];
        if($user_leaves != NULL){
            foreach($user_leaves as $user_leave){
                if($user_leave->leave_type == LeaveType::CASSUAL){
                    $leaves['casual'] = $user_leave->count;
                }
                if($user_leave->leave_type == LeaveType::VACASION){
                    $leaves['vacation'] = $user_leave->count;
                }
            }
        }

        return view('report.balance_leave', ['user' => $user, 'leaves' => $leaves]);
    }

    public function leaveStatus(){
        $user = User::where('id',\Auth::id())->with('team')->first();
        $leaves = Leave::where('user_id', \Auth::id())
                ->whereYear('start_date', Carbon::now()->year)
                ->with('leaveType')->get();
        return view('report.leave_status', ['user' => $user, 'leaves' => $leaves]);
    }

    public function holiday(){
        $holidays = Holiday::get();
        return view('report.holiday', ['holidays' => $holidays]);
    }

    public function allLeaveBalance(){
        $user_cassual_leaves = UserLeave::where('year', Carbon::now()->year)->where('leave_type', LeaveType::CASSUAL)
                                ->with('user')->get();

        $user_vacasion_leaves = UserLeave::where('year', Carbon::now()->year)->where('leave_type', LeaveType::VACASION)
                                ->with('user')->get();

        // dd($user_cassual_leaves, $user_vacasion_leaves);

        $user_leaves = [];
        
        if($user_cassual_leaves->isNotempty()){
            foreach($user_cassual_leaves as $user_cassual_leave){
                $user_leave = [
                    'epf_no' => $user_cassual_leave->user->epf_no,
                    'user_name' => $user_cassual_leave->user->name,
                    'cassual_count' => $user_cassual_leave->count,
                    'vacasion_count' =>  0
                ];
                array_push($user_leaves, $user_leave);
                $user_leave = [];
            }
        }


        $temp = [];
        $all_leaves = [];

        if($user_vacasion_leaves->isNotempty()){
            foreach($user_vacasion_leaves as $user_vacasion_leave){
                foreach($user_leaves as $user_leave){
                    if($user_leave['epf_no'] == $user_vacasion_leave->user->epf_no){
                        $temp = [
                            'epf_no' => $user_leave['epf_no'],
                            'user_name' => $user_leave['user_name'],
                            'cassual_count' => $user_leave['cassual_count'],
                            'vacasion_count' =>  $user_vacasion_leave->count
                        ];
                        array_push($all_leaves, $temp);
                        $temp = [];
                    }
                }
            }
        }else{
            $all_leaves = $user_leaves;
        }
        
        return view('report.all_leave_balance', ['user_leaves' => $all_leaves]);
    }

    public function allLeaveSummary(){
        $user_cassual_leaves = UserLeave::where('year', Carbon::now()->year)->where('leave_type', LeaveType::CASSUAL)
        ->with('user.team')->get();

        $user_vacasion_leaves = UserLeave::where('year', Carbon::now()->year)->where('leave_type', LeaveType::VACASION)
        ->with('user.team')->get();

        $user_other_leaves = UserLeave::where('year', Carbon::now()->year)->where('leave_type', LeaveType::OTHER)
        ->with('user.team')->get();

        $user_special_leaves = UserLeave::where('year', Carbon::now()->year)->where('leave_type', LeaveType::SPECIAL)
        ->with('user.team')->get();

        $temp = [];
        $temp_c = [];
        $temp_v = [];
        $temp_o = [];
        $all = [];

        // Add cassual_count to array
        if($user_cassual_leaves->isNotEmpty()){
            foreach($user_cassual_leaves as $user_cassual_leave){
                $temp = [
                    'epf_no' => $user_cassual_leave->user->epf_no,
                    'user_name' => $user_cassual_leave->user->name,
                    'designation' => $user_cassual_leave->user->designation,
                    'team' => $user_cassual_leave->user->team->name,
                    'cassual_count' => $user_cassual_leave->count
                ]; 
                array_push($temp_c, $temp);
            }
        }

        // Add vacasion_count to array
        if($user_vacasion_leaves->isNotEmpty()){
            foreach($user_vacasion_leaves as $user_vacasion_leave){
                foreach($temp_c as $tem){
                    if($tem['epf_no'] == $user_vacasion_leave->user->epf_no){
                        $temp = [
                            'epf_no' => $tem['epf_no'],
                            'user_name' => $tem['user_name'],
                            'designation' => $tem['designation'],
                            'team' => $tem['team'],
                            'cassual_count' => $tem['cassual_count'],
                            'vacasion_count' => $user_vacasion_leave->count
                        ];
                        array_push($temp_v, $temp);
                    }
                } 
            }
        }else{
            foreach($temp_c as $tem){
                    $temp = [
                        'epf_no' => $tem['epf_no'],
                        'user_name' => $tem['user_name'],
                        'designation' => $tem['designation'],
                        'team' => $tem['team'],
                        'cassual_count' => $tem['cassual_count'],
                        'vacasion_count' => 0
                    ];
                    array_push($temp_v, $temp);
            }
        }

        // Add other_count to array
        if($user_other_leaves->isNotEmpty()){
            foreach($user_other_leaves as $user_other_leave){
                foreach($temp_v as $tem){
                    if($tem['epf_no'] == $user_other_leave->user->epf_no){
                        $temp = [
                            'epf_no' => $tem['epf_no'],
                            'user_name' => $tem['user_name'],
                            'designation' => $tem['designation'],
                            'team' => $tem['team'],
                            'cassual_count' => $tem['cassual_count'],
                            'vacasion_count' => $tem['vacasion_count'],
                            'other_count' => $user_other_leave->count
                        ];
                        array_push($temp_o, $temp);
                    }
                } 
            }
        }else{
            foreach($temp_v as $tem){
                $temp = [
                    'epf_no' => $tem['epf_no'],
                    'user_name' => $tem['user_name'],
                    'designation' => $tem['designation'],
                    'team' => $tem['team'],
                    'cassual_count' => $tem['cassual_count'],
                    'vacasion_count' => $tem['vacasion_count'],
                    'other_count' => 0
                ];
                array_push($temp_o, $temp);
            } 
        }        
        
        // Add special_count to array
        if($user_special_leaves->isNotEmpty()){
            foreach($user_special_leaves as $user_special_leave){
                foreach($temp_o as $tem){
                    if($tem['epf_no'] == $user_special_leave->user->epf_no){
                        $temp = [
                            'epf_no' => $tem['epf_no'],
                            'user_name' => $tem['user_name'],
                            'designation' => $tem['designation'],
                            'team' => $tem['team'],
                            'cassual_count' => $tem['cassual_count'],
                            'vacasion_count' => $tem['vacasion_count'],
                            'other_count' => $tem['other_count'],
                            'special_count' => $user_special_leave->count
                        ];
                        array_push($all, $temp);
                    }
                } 
            }
        }else{
            foreach($temp_o as $tem){
                    $temp = [
                        'epf_no' => $tem['epf_no'],
                        'user_name' => $tem['user_name'],
                        'designation' => $tem['designation'],
                        'team' => $tem['team'],
                        'cassual_count' => $tem['cassual_count'],
                        'vacasion_count' => $tem['vacasion_count'],
                        'other_count' => $tem['other_count'],
                        'special_count' => 0
                    ];
                    array_push($all, $temp);
            } 
        }

        return view('report.all_leave_summary', ['all_leaves' => $all]);
    }

    public function allLeaveDetail($type=NULL){
        $users = User::whereNotIn('user_type', [0,1,4])->get();
        return view('report.users_list', ['type' => $type, 'users' => $users]);
    }
}
