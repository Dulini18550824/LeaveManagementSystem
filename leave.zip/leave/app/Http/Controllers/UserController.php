<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\User;
use Auth;

class UserController extends Controller
{
    public function profile($id=NULL){

        if($id==NULL){
            $user = User::with('team')->find(Auth::id());
        }else{
            $user = User::with('team')->find($id);
        }
        return view('user.profile', ['user' => $user]);
    }

    public function empProfile(){
        $users = User::whereNotIn('user_type', [0,1,4])->where('is_verified','true')->get();
        return view('user.emp-profiles', ['users' => $users]);
    }

    public function index() {
        $users = User::whereNotIn('user_type', [0])->paginate(8);
        return view('user/index', compact('users'));
    }

    public function edit($user_id) {
        $user = User::findOrFail($user_id);
        return view('user/edit', compact('user'));
    }

    public function delete($user_id) {
        $user = User::findOrFail($user_id);
        $user->delete();

        return redirect()->back()->with('success', 'User has been deleted!');
    }

    public function update($user_id, Request $request) {

        $validated = $request->validate([
            'name' => 'required|required|regex:/^[\pL\s\-]+$/u|max:50',
            'email' => 'required|email|unique:users,email,'. $user_id . ',id',
            'epf_no' => 'required',
            'designation' => 'required',
            'password' => 'sometimes',
            'team_id' => 'required|numeric',
            'first_appointment' => 'required|date',
            'mobile_no' => 'required|numeric',
            'work_from' => 'required',
            'work_to' => 'required',   
        ]);

        $user = User::findOrFail($user_id);
        $user->update($request->except(['password']));

        if (!empty($request->input('password'))) {
            $user->update(['password' => Hash::make($request->input('password'))]);
        }

        return redirect()->back()->with('success', 'User Updated!');

    }

    public function create() {
        return view('user/create');
    }

    public function store(Request $request) {

        ///return response()->json($request->all());
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
            'epf_no' => ['required', 'string'],
            'designation' => ['required'],
            'first_appointment' => ['required'],
            'phone_no' => ['required', 'regex:/(07)[0-9]{8}/'],
            'work_from' => ['required'],
            'work_to' => ['required'],
            'role' => ['required']
        ]);

        $data = $request->all();

        User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => Hash::make($data['password']),
            'user_type' => $data['role'],
            'epf_no' => $data['epf_no'],
            'designation' => $data['designation'],
            'team_id' => $data['team'],
            'first_appointment' => $data['first_appointment'],
            'mobile_no' => $data['phone_no'],
            'work_from' => $data['work_from'],
            'work_to' => $data['work_to'],
            'is_verified' => 'true'
        ]);


        return redirect()->back()->with('success', 'User has been created!');
    }

    public function verify($user_id) {
        $user = User::findOrFail($user_id);

        $user->update(['is_verified' => 'true']);
        //return resposnse()->json($user->is_verified);
        return redirect()->back()->with('success', 'User Verified!');
        
    }

    public function dashboard() {
        $user_type = \Auth::user()->user_type;
        if ($user_type == 0) {
            return redirect()->route('admin.index');
        } else if ($user_type == 1) {
            return redirect()->route('leave.manage');
        } else if ($user_type == 2) {
            return redirect()->route('home');
        } else if ($user_type == 3) {
            return redirect()->route('home');
        } else if ($user_type == 4) {
            return redirect()->route('leave.manage');
        }
    }


}
