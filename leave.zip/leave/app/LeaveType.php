<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LeaveType extends Model
{
    public const CASSUAL = 1;
    public const VACASION = 2;
    public const SHORT = 3;
    public const OTHER = 4;
    public const SPECIAL = 5;

    protected $fillable = ['id', 'type'];

    public function leave($type){
        return $this->hasMany('App\Leave');
    }
}
