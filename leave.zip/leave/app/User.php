<?php

namespace App;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use Notifiable;

    public const TYPE_ADMIN = 0;
    public const TYPE_HOD = 1;
    public const TYPE_ACTING = 2;
    public const TYPE_EMPLOYEE = 3;
    public const TYPE_REGISTAR = 4;


    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password', 'user_type', 'epf_no', 'designation','team_id', 'first_appointment', 'mobile_no', 'work_from', 'work_to', 'is_acting', 'is_verified'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function leaves(){
        return $this->hasMany('App\Leave');
    }

    public function team(){
        return $this->belongsTo('App\Team');
    }

}
