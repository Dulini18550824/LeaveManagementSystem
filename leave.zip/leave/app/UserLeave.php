<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserLeave extends Model
{
    protected $fillable = ['user_id', 'year', 'month', 'leave_type', 'count'];

    public function leaveType(){
        return $this->belongsTo('App\LeaveType', 'type');
    }

    public function user(){
        return $this->belongsTo('App\User');
    }
}
