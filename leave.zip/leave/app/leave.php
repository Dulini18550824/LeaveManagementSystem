<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Leave extends Model
{
    public const PENDING = 0;
    public const APPROVED = 1;
    public const REJECTED = 2;
    public const FORWADED = 3;


    protected $fillable = ['user_id', 'leave_type', 'no_of_days', 'reason', 'start_date', 'end_date', 'time_from', 'time_to', 'file_upload', 'acting_user_id', 'status'];
    
    protected $dates = ['start_date', 'end_date'];

    public function user(){
        return $this->belongsTo('App\User');
    }

    public function acting(){
        return $this->belongsTo('App\User', 'acting_user_id');
    }

    public function leaveType(){
        return $this->belongsTo('App\LeaveType', 'leave_type');
    }

    public function fileUploads(){
        return $this->hasMany('App\FileUpload');
    }
}
