<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateLeavesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('leaves', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id');
            $table->tinyInteger('leave_type');
            $table->double('no_of_days',8,1)->nullable();
            $table->string('reason')->nullable();
            $table->dateTime('start_date');
            $table->dateTime('end_date');
            $table->time('time_from')->nullable();
            $table->time('time_to')->nullable();
            $table->string('file_upload')->nullable();
            $table->integer('acting_user_id')->nullable();
            $table->tinyInteger('status')->default(0);
            $table->dateTime('approved_at')->nullable();
            $table->timestamps();

            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('leaves');
    }
}
