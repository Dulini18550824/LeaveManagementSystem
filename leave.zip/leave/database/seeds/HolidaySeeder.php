<?php

use Illuminate\Database\Seeder;
use App\Holiday;

class HolidaySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Holiday::create([
            'name' => 'Thai Pongal Day',
            'date' => '2021-01-14'
        ]);
        Holiday::create([
            'name' => 'Duruthu Poya Day',
            'date' => '2021-01-28'
        ]);
        Holiday::create([
            'name' => 'National Day',
            'date' => '2021-02-04'
        ]);
        Holiday::create([
            'name' => 'Navam Poya Day',
            'date' => '2021-02-26'
        ]);
        Holiday::create([
            'name' => 'Mahasivarathri Day',
            'date' => '2021-03-11'
        ]);
        Holiday::create([
            'name' => 'Madin Poya Day',
            'date' => '2021-03-28'
        ]);
        Holiday::create([
            'name' => 'Good Friday',
            'date' => '2021-04-02'
        ]);
        Holiday::create([
            'name' => 'New Year Eve',
            'date' => '2021-04-13'
        ]);
        Holiday::create([
            'name' => 'New Year',
            'date' => '2021-04-14'
        ]);
        Holiday::create([
            'name' => 'Bak Poya Day',
            'date' => '2021-04-26'
        ]);
        Holiday::create([
            'name' => 'Labour Day',
            'date' => '2021-05-01'
        ]);
        Holiday::create([
            'name' => 'Id-Ul-Fitr',
            'date' => '2021-05-14'
        ]);
        Holiday::create([
            'name' => 'Wesak Poya Day',
            'date' => '2021-05-26'
        ]);
        Holiday::create([
            'name' => 'Wesak Poya Holiday',
            'date' => '2021-05-27'
        ]);
        Holiday::create([
            'name' => 'Poson Poya Day',
            'date' => '2021-06-24'
        ]);
        Holiday::create([
            'name' => 'Idul Adha',
            'date' => '2021-07-21'
        ]);
        Holiday::create([
            'name' => 'Esala Poya Day',
            'date' => '2021-07-23'
        ]);
        Holiday::create([
            'name' => 'Nikini Poya Day',
            'date' => '2021-08-22'
        ]);
        Holiday::create([
            'name' => 'Binara Poya Day',
            'date' => '2021-09-20'
        ]);
        Holiday::create([
            'name' => 'Milad-Un-Nabi',
            'date' => '2021-10-19'
        ]);
        Holiday::create([
            'name' => 'Vap Poya Day',
            'date' => '2021-10-20'
        ]);
        Holiday::create([
            'name' => 'Deepavali Festival day',
            'date' => '2021-11-04'
        ]);
        Holiday::create([
            'name' => 'Ill Poya Day',
            'date' => '2021-11-18'
        ]);
        Holiday::create([
            'name' => 'Unduvap Poya Day',
            'date' => '2021-12-18'
        ]);
        Holiday::create([
            'name' => 'Christmas Day',
            'date' => '2021-12-25'
        ]);
    }
}
