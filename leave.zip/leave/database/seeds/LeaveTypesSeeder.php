<?php

use Illuminate\Database\Seeder;
use App\LeaveType;

class LeaveTypesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        LeaveType::create([
            'type' => 'Casual'
        ]);

        LeaveType::create([
            'type' => 'Vacation'
        ]);

        LeaveType::create([
            'type' => 'Short'
        ]);

        LeaveType::create([
            'type' => 'Other'
        ]);

        LeaveType::create([
            'type' => 'Special'
        ]);

    }
}
