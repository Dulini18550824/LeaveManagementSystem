<?php

use Illuminate\Database\Seeder;
use App\Team;

class TeamSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Team::create([
            'name' => 'Software Development'
        ]);
        Team::create([
            'name' => 'Web Development'
        ]);
        Team::create([
            'name' => 'IT Infrastructure & Network'
        ]);
        Team::create([
            'name' => 'Instructors'
        ]);
        Team::create([
            'name' => 'IT Officers'
        ]);
        Team::create([
            'name' => 'AV Officers'
        ]);
        Team::create([
            'name' => 'Clarical'
        ]);
        Team::create([
            'name' => 'Other'
        ]);
    }
}
