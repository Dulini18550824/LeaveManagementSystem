<?php

use Illuminate\Database\Seeder;
use App\User;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        User::create([
            'name' => 'HOD',
            'email' => 'hod@mail.com',
            'password' =>  Hash::make('asdf1234'),
            'user_type' => User::TYPE_HOD,
            'epf_no' => '00000000',
            'designation' => 'HOD',
            'team_id' => 0,
            'is_acting' => 1,
            'is_verified' => 'true'
        ]);

        User::create([
            'name' => 'Admin',
            'email' => 'admin@mail.com',
            'password' =>  Hash::make('asdf1234'),
            'user_type' => User::TYPE_ADMIN,
            'epf_no' => '00000000',
            'designation' => 'ADMIN',
            'team_id' => 0,
            'is_acting' => 0,
            'is_verified' => 'true'
        ]);

        User::create([
            'name' => 'Registar',
            'email' => 'registar@mail.com',
            'password' =>  Hash::make('asdf1234'),
            'user_type' => User::TYPE_REGISTAR,
            'epf_no' => '00000000',
            'designation' => 'REGISTAR',
            'team_id' => 0,
            'is_acting' => 0,
            'is_verified' => 'true'
        ]);
    }
}
