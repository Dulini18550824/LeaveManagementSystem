<script>
import '@fullcalendar/core/vdom' // solves problem with Vite
import FullCalendar from '@fullcalendar/vue'
import dayGridPlugin from '@fullcalendar/daygrid'
import interactionPlugin from '@fullcalendar/interaction'

export default {
    mounted(){
        axios.get('/calender/leave')
                .then(response => {
                    this.calendarOptions.eventSources = response.data.data
                    console.log(response.data.data)
                })

    },
    components: {
        FullCalendar // make the <FullCalendar> tag available
    },
    data() {
        return {
        calendarOptions: {
            plugins: [ dayGridPlugin, interactionPlugin ],
            initialView: 'dayGridMonth',
            dateClick: this.handleDateClick,
            height: 350,
            eventSources:[],
            // events: []
            // eventSources:this.leave
        },

        leaves: null
        }
    },
    methods: {
        handleDateClick: function(arg) {
            alert('date click! ' + arg.dateStr)
        },

        getLeave(){
            axios.get('/calender/leave')
                .then(response => {
                    console.log(response)
                    leave = response.data.data
                })
        }
    }
}
</script>
<template>
  <FullCalendar :options="calendarOptions" />
</template>