<script>
import '@fullcalendar/core/vdom' // solves problem with Vite
import FullCalendar from '@fullcalendar/vue'
import dayGridPlugin from '@fullcalendar/daygrid'
import interactionPlugin from '@fullcalendar/interaction'

export default {
    props: ['data'],
    mounted(){
         this.calendarOptions.eventSources = this.data
        // axios.get('/calender/leave')
        //         .then(response => {
        //             this.calendarOptions.eventSources = response.data.data
        //         })

    },
    components: {
        FullCalendar // make the <FullCalendar> tag available
    },
    data() {
        return {
        calendarOptions: {
            plugins: [ dayGridPlugin, interactionPlugin ],
            initialView: 'dayGridMonth',
            dateClick: this.handleDateClick,
            // height: 350,
            eventSources:[],
            // events: []
            // eventSources:this.leave
        },

        leaves: null
        }
    },
    methods: {
        handleDateClick: function(arg) {
            alert('date click! ' + arg.dateStr)
        },
    }
}
</script>
<template>
  <FullCalendar :options="calendarOptions" />
</template>