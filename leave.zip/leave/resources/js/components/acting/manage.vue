<template>
<div>
    <div class="container">
            <div v-if="warningMsg" class="alert alert-danger">
                {{warningMsg}}
            </div>

            <div v-if="successMsg" class="alert alert-success">
                {{successMsg}}
            </div>
    </div>

    <div class="table-padding">
        <h3>Manage Acting</h3>
        <table class="table table-striped">
            <thead>
                <tr>
                <th>Name</th>
                <th>Email</th>
                <th>EPF No.</th>
                <th>Designation</th>
                <th>Team</th>
                <th></th>
                </tr>
            </thead>
            <tbody v-if="users.length != 0">
                <tr v-for="user in users" v-bind:key="user.id">
                    <td>{{user.name}}</td>
                    <td>{{user.email}}</td>
                    <td>{{user.epf_no}}</td>
                    <td>{{user.designation}}</td>
                    <td>{{user.team.name}}</td>
                    <td v-if="acting == false && user.is_acting == 0"><button type="button" class="btn btn-primary" @click="makeActing(user.id)">Make Acting</button></td>
                    <td v-else-if="user.is_acting == 1"><button type="button" class="btn btn-danger" @click="removeActing(user.id)">Remove Acting</button></td>
                    <td v-else-if="user.is_acting == 2"><button type="button" class="btn btn-danger" @click="removeActing(user.id)">Remove Pending</button></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
</template>

<script>
    export default {
        props:['users'],
        mounted() {
            this.users.forEach(element => {
                if (element.is_acting == 1 || element.is_acting == 2) this.acting = true
            });
        },

        data(){
            return{
                warningMsg:"",
                successMsg:"",
                acting: false,
            }
        }, 

        methods:{
            makeActing(id){
                axios.post("/user/"+id+"/make-acting")
                .then(response => {
                    if(response.data.states == 1002){
                        this.warningMsg =  response.data.data;
                    }else if(response.data.states == 200){
                        this.successMsg = "Successfull!"
                    }
                    setTimeout(function () { location.reload(true); }, 1000);
                })
            },

            removeActing(id){
                axios.post("/user/"+id+"/remove-acting")
                .then(response => {
                    if(response.data.states == 1002){
                        this.warningMsg = "Failed"
                    }else if(response.data.states == 200){
                        this.successMsg = "Successfull!"
                    }
                    setTimeout(function () { location.reload(true); }, 1000);
                })
            }
        }
    }
</script>