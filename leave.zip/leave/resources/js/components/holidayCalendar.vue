<script>
import '@fullcalendar/core/vdom' // solves problem with Vite
import FullCalendar from '@fullcalendar/vue'
import dayGridPlugin from '@fullcalendar/daygrid'
import interactionPlugin from '@fullcalendar/interaction'

export default {
    mounted(){
        // axios.get('/calender/leave')
        //         .then(response => {
        //             this.calendarOptions.eventSources = response.data.data
        //         })

    },
    components: {
        FullCalendar // make the <FullCalendar> tag available
    },
    data() {
        return {
        calendarOptions: {
            plugins: [ dayGridPlugin, interactionPlugin ],
            initialView: 'dayGridMonth',
            dateClick: this.handleDateClick,
            height: 500,
            // eventSources:[],
            events: [
                {
                    title: 'Poya Day',
                    date: '2021-09-01',   
                },
                {
                    title: 'Public holiday',
                    date: '2021-09-11',   
                }
            ]
        },

        leaves: null
        }
    },
    methods: {
        handleDateClick: function(arg) {
            alert('date click! ' + arg.dateStr)
        },

        // getLeave(){
        //     axios.get('/calender/leave')
        //         .then(response => {
        //             console.log(response)
        //             leave = response.data.data
        //         })
        // }
    }
}
</script>
<template>
  <FullCalendar :options="calendarOptions" />
</template>