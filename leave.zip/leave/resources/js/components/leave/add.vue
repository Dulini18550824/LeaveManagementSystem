<template>
    <div class="container">
        <h3>Leave Application</h3>
        <form>
            <div class="row mb-4">
                <div class="col">
                    <label for="leave_type">Leave Type</label>
                    <select name="leave_type" id="leave_type" class="form-control" v-model="leave.leave_type">
                        <option value="1">Full Day</option>
                        <option value="2">Half Day</option>
                        <option value="3">Short Leave</option>
                        <option value="4">Other</option>
                    </select>
                </div>

                <div class="col">
                    <label for="reason">Reason</label>
                    <input type="text" class="form-control" placeholder="Optional" name="reason" v-model="leave.reason">
                    <!-- @error('reason')
                        <div class="error-msg">{{ $reason }}</div>
                    @enderror -->
                </div>

            </div>

            <div class="row mb-4">
                <div class="col">
                    <label for="start_date">Start Date</label>
                    <input type="date" class="form-control" placeholder="Optional" name="start_date" v-model="leave.start_date">
                </div>

                <div class="col">
                    <label for="end_date">End Date</label>
                    <input type="date" class="form-control" placeholder="Optional" name="end_date" v-model="leave.end_date">
                </div>
            </div>

            <div class="row mb-4">
                <div class="col">
                    <label for="file_upload">File Upload</label>
                    <input type="file" class="form-control" placeholder="Optional" name="file_upload">
                </div>

                <div class="col">
                    <label for="acting_name">Acting Person's Name</label>
                    <input type="text" class="form-control" placeholder="Optional" name="acting_name" v-model="leave.acting_name">
                </div>
            </div>

            <div class="row mb-4">
                <div class="col">
                    <label for="acting_contact_no">Acting Person's Contact No.</label>
                    <input type="text" class="form-control" placeholder="" name="acting_contact_no" v-model="leave.acting_contact_no">
                </div>

                <div class="col">
                    <label for="acting_contact_email">Acting Person's e-mail</label>
                    <input type="email" class="form-control" placeholder="" name="acting_contact_email" v-model="leave.acting_contact_email">
                </div>
            </div>

            <button type="submit" class="btn btn-primary" style="float: right;">Submit</button>

        </form>
    </div>
</template>

<script>
    export default {
        mounted() {
            console.log('Component mounted.')
        },

        data(){
            return{
                leave:{
                    leave_type:"",
                    reason:"",
                    start_date:"",
                    end_date:"",
                    file_upload:"",
                    acting_name:"",
                    acting_contact_no:"",
                    acting_contact_email:""
                },
                // asb:"casasc"

            }
        }, 

        methods:{
            validation(){
                alert("aaaaa")
            },

            checkEmpty(){
            }
        }
    }
</script>
