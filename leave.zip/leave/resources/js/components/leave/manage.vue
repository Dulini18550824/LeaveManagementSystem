<template>
<div>
    <div class="container">
            <div v-if="warningMsg" class="alert alert-danger">
                {{warningMsg}}
            </div>

            <div v-if="successMsg" class="alert alert-success">
                {{successMsg}}
            </div>
    </div>


    <div class="table-padding">
        <h3>Manage Leave</h3>
        <table class="table table-striped">
        <thead>
            <tr>
            <th>Name</th>
            <th>Leave Type</th>
            <th>No of Leave</th>
            <th>Reason</th>
            <th>Start Date</th>
            <th>End Date</th>
            <th>From</th>
            <th>To</th>
            <th>Working hours</th>
            <th>Acting Name</th>
            <th>File</th>
            <!-- <th>Acting Mobile No.</th> -->
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            </tr>
        </thead>
        <tbody v-if="leaves.length != 0">
            <tr v-for="leave in leaves" v-if="checkAvailability(leave)" v-bind:key="leave.id">
                <td>{{leave.user.name}}</td>
                <td v-if="leave.leave_type == 1">Casual</td>
                <td v-if="leave.leave_type == 2">Vacasion</td>
                <td v-if="leave.leave_type == 3">Short</td>
                <td v-if="leave.leave_type == 4">Other</td>
                <td v-if="leave.leave_type == 5">Special</td>
                <td v-if="leave.no_of_days != null">{{leave.no_of_days}}</td>
                <td v-else>-</td>
                <td>{{leave.reason}}</td>
                <td>{{formatDate(leave.start_date)}}</td>
                <td>{{formatDate(leave.end_date)}}</td>
                <td v-if="leave.time_from != null">{{formatTime(leave.time_from)}}</td>
                <td v-else>-</td>
                <td v-if="leave.time_to != null">{{formatTime(leave.time_to)}}</td>
                <td v-else>-</td>
                <td>{{formatTime(leave.user.work_from)}} - {{formatTime(leave.user.work_to)}}</td>
                <td v-if="leave.acting != null">{{leave.acting.name}}</td>
                <td v-else>-</td>
                <td v-if="leave.file_upload != null"><a :href="leave.file_upload" target="blank" class="btn btn-primary btn-height-58">View File</a></td>
                <td v-else>-</td>
                <!-- <td v-if="leave.acting != null">{{leave.acting.mobile_no}}</td>
                <td v-else>-</td> -->

                <td v-if="leave.file_uploads.length != 0" v-for="file in leave.file_uploads">
                    <a :href="file.location" target="blank" class="btn btn-primary btn-height-58">Other Documents</a>
                </td>

                <td v-if="(auth.user_type == 4 && leave.leave_type == 5) || (auth.user_type == 1 && leave.leave_type != 5)"><button type="submit" class="btn btn-success btn-height-58" @click="approve(leave.id,leave.leave_type)">Approve</button></td>
                <td v-if="(auth.user_type == 4 && leave.leave_type == 5) || (auth.user_type == 1 && leave.leave_type != 5)"><button type="submit" class="btn btn-danger btn-height-58" @click="reject(leave.id,leave.leave_type)">Reject</button></td>
                <!-- <td v-else><button class="btn btn-primary btn-height-58" @click="downloadForm(leave.id)">Download Leave Form</button></td> -->
                <td v-if="leave.leave_type == 5"><a class="btn btn-primary btn-height-58" a :href="'/special-leave/'+leave.id+'/download'">Download Leave Form</a></td>
                <td v-if="(auth.user_type == 4 && leave.leave_type == 5) || (auth.user_type == 1 && leave.leave_type != 5)">
                    <button type="submit" class="btn btn-warning btn-height-58" @click="sendWarning(leave.user_id)">Send Warning</button>
                </td>
                <td v-if="auth.user_type == 1 && leave.leave_type == 5">
                    <button type="submit" class="btn btn-primary btn-height-58" @click="forwardToRegistar(leave.id)">Send To Registar</button>
                </td>
                
            </tr>
        </tbody>
        <tbody v-else>
            <tr><td class="td-bgcolor">No pending leaves</td></tr>
        </tbody>
        </table>

    </div>

</div>
</template>

<script>
import moment from 'moment';
    export default {
        props:[
            'leaves', 
            'auth',
        ],
        mounted() {
            console.log(this.auth)
        },

        data(){
            return{
                leave:{
                    leave_type:"",
                    reason:"",
                    start_date:"",
                    end_date:"",
                    file_upload:"",
                    acting_name:"",
                    acting_contact_no:"",
                    acting_contact_email:""
                },
                warningMsg:"",
                successMsg:"",
                user_type : this.usertype
            }
        }, 

        methods:{
            //acting user leave validation
            checkAvailability(leave) {
                if (this.auth.user_type == 3 && this.auth.is_acting == 1) {
                    var start = new Date(leave.start_date);
                    var end = new Date(leave.end_date);
                    var diff = new Date(end.getTime() - start.getTime());
                    if (diff.getUTCDate() - 1 <= 3 && (leave.leave_type == 1 || leave.leave_type == 2 || leave.leave_type == 3) ) {
                        return true;
                    }
                    return false;
                }
                return true;
            },
            formatDate(value){
                return moment(String(value)).format('YYYY-MM-DD')
            },

            formatTime(value){
                var m = moment(value, "hh:mm A")
                console.log()
                return m.format('hh:mm A')
            },

            approve(id,leaveType){
                axios.post("/leave/"+id+"/approve")
                .then(response => {
                    if(response.data.data == 1001){
                        this.warningMsg = "Not Aproved"
                    }else if(response.data.data == 200){
                        this.successMsg = "Approved"
                    }
                    setTimeout(function () { location.reload(true); }, 1000);
                })
            },

            reject(id,leaveType){
                axios.post("/leave/"+id+"/reject")
                .then(response => {
                    if(response.data.states == 1001){
                        this.warningMsg = response.data.data
                    }else if(response.data.states == 200){
                        this.successMsg = response.data.data
                    }
                    setTimeout(function () { location.reload(true); }, 1000);
                })
            },

            sendWarning(user_id){
                axios.post("/leave/user/"+user_id+"/warning")
                .then(response => {
                    if(response.data.status == 1001){
                        this.warningMsg = response.data.data
                    }else if(response.data.status == 200){
                        this.successMsg = response.data.data
                    }
                    setTimeout(function () { location.reload(true); }, 1000);
                })
            },

            forwardToRegistar(leave_id) {
                axios.post("/leave/"+leave_id+"/forward")
                .then(response => {
                    if(response.status == 200){
                        this.successMsg = "Forwareded"
                    }else{
                        this.successMsg = "Not Forwareded"
                    }
                    setTimeout(function () { location.reload(true); }, 3000);
                })
            }
        }
    }
</script>
