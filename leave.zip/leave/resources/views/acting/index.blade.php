@extends('layouts.app')

@section('content')
<acting-manage :users='{{ json_encode($users) }}'></acting-manage>
@endsection