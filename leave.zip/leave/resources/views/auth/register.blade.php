@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">{{ __('Register') }}</div>

                <div class="card-body">
                    <form method="POST" action="{{ route('register') }}">
                        @csrf

                        <div class="row">
                        <div class="col-md-6">
                            <div class="form-group row">
                                <label for="name" class="col-md-4 col-form-label text-md-right">{{ __('Name') }}
                                <label class="error-msg">*</label>
                                </label>

                                <div class="col-md-6">
                                    <input id="name" type="text" class="form-control @error('name') is-invalid @enderror" name="name" value="{{ old('name') }}" required autocomplete="name" autofocus>

                                    @error('name')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="email" class="col-md-4 col-form-label text-md-right">{{ __('E-Mail Address') }}
                                    <label style="color:red;">*</label>
                                </label>

                                <div class="col-md-6">
                                    <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email">

                                    @error('email')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="password" class="col-md-4 col-form-label text-md-right">{{ __('Password') }}
                                    <label style="color:red;">*</label>
                                </label>

                                <div class="col-md-6">
                                    <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="new-password">

                                    @error('password')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="password-confirm" class="col-md-4 col-form-label text-md-right">{{ __('Confirm Password') }}</label>

                                <div class="col-md-6">
                                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="epf_no" class="col-md-4 col-form-label text-md-right">{{ __('EPF No') }}
                                    <label style="color:red;">*</label>
                                </label>

                                <div class="col-md-6">
                                    <input id="epf_no" type="text" class="form-control @error('epf_no') is-invalid @enderror" name="epf_no" value="{{ old('epf_no') }}" required autocomplete="epf_no" autofocus>

                                    @error('epf_no')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="designation" class="col-md-4 col-form-label text-md-right">{{ __('Designation') }}
                                    <label style="color:red;">*</label>
                                </label>

                                <div class="col-md-6">
                                    <input id="designation" type="text" class="form-control @error('designation') is-invalid @enderror" name="designation" value="{{ old('designation') }}" required autocomplete="designation" autofocus>

                                    @error('designation')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">

                            <div class="form-group row">
                                <label for="team" class="col-md-4 col-form-label text-md-right">{{ __('Team') }}</label>

                                <div class="col-md-6">
                                    <select name="team" id="team" class="form-control">
                                        <option value="0"></option>
                                        <option value="1">Software Development</option>
                                        <option value="2">Web Development</option>
                                        <option value="3">IT Infrastructure & Network</option>
                                        <option value="4">Instructors</option>
                                        <option value="5">IT Officers</option>
                                        <option value="6">AV Officers</option>
                                        <option value="7">Clarical</option>
                                        <option value="8">Other</option>
                                    </select>

                                    @error('team')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="first_appointment" class="col-md-4 col-form-label text-md-right">{{ __('Appointment date') }}
                                    <label style="color:red;">*</label>
                                </label>

                                <div class="col-md-6">
                                    <input id="first_appointment" type="date" class="form-control @error('first_appointment') is-invalid @enderror" name="first_appointment" value="{{ old('first_appointment') }}" required autocomplete="first_appointment" autofocus>

                                    @error('first_appointment')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="phone_no" class="col-md-4 col-form-label text-md-right">{{ __('Mobile No') }}
                                    <label style="color:red;">*</label>
                                </label>

                                <div class="col-md-6">
                                    <input id="phone_no" type="text" class="form-control @error('phone_no') is-invalid @enderror" name="phone_no" value="{{ old('phone_no') }}" required autocomplete="phone_no" autofocus placeholder="07xxxxxxxx">

                                    @error('phone_no')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="work_from" class="col-md-4 col-form-label text-md-right">{{ __('Wrok from') }}
                                    <label style="color:red;">*</label>
                                </label>

                                <div class="col-md-6">
                                    <input id="work_from" type="time" class="form-control @error('work_from') is-invalid @enderror" name="work_from" value="{{ old('work_from') }}" required autocomplete="work_from" autofocus>

                                    @error('work_from')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="work_to" class="col-md-4 col-form-label text-md-right">{{ __('Wrok to') }}
                                    <label style="color:red;">*</label>
                                </label>

                                <div class="col-md-6">
                                    <input id="work_to" type="time" class="form-control @error('work_to') is-invalid @enderror" name="work_to" value="{{ old('work_to') }}" required autocomplete="work_to" autofocus>

                                    @error('work_to')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group row mb-0">
                                <div class="col-md-12 offset-md-8">
                                    <button type="submit" class="btn btn-primary">
                                        {{ __('Register') }}
                                    </button>
                                </div>
                            </div>
                        </div>
                        </div>



                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
