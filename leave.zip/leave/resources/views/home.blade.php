@extends('layouts.app')

@section('content')

@if(isset($acting_approval))
    <div class="alert alert-success alert-dismissible fade show" style="margin-top: 30px">
        <span>HOD has requested you to be Acting HOD
            <a href="{{ route('accept-acting') }}" class="btn btn-primary ml-4">Accept</a>
            <a href="{{ route('reject-acting') }}" class="btn btn-danger ml-2">Reject</a>
        </span>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
@endif

<div class="container">
    <div class="row">
        <div class="col">
        <h3>Number of Leave Taken</h3>

        @if(auth()->user()->is_acting != 1)
        <a href="/leave/select">
            <button type="button" class="btn btn-primary mb-2">Apply / Edit Leave</button>
        </a>
        @endif
        
        <table class="table table-striped">
            <tbody>
                <tr>
                <td>Casual Leave</td>
                <td>{{$leaves['casual']}}</td>
                </tr>
                <tr>
                <td>Vacation Leave</td>
                <td>{{$leaves['vacation']}}</td>
                </tr>
                <tr>
                <td>Short Leave</td>
                <td>{{$leaves['short']}}</td>
                </tr>
                <tr>
                <td>Other Leave</td>
                <td>{{$leaves['other']}}</td>
                </tr>
                <tr>
                <td>Special Leave</td>
                <td>{{$leaves['special']}}</td>
                </tr>        
            </tbody>
        </table>
        
        </div>

        <div class="col">
        <h3>My Calendar</h3> 
        
        <!-- <button type="button" class="btn btn-primary">Yearly Calendar</button>
        <button type="button" class="btn btn-primary">Holiday Calendar</button>
        <button type="button" class="btn btn-primary">Team Calendar</button> -->

        <calendar></calendar>

        <div class="row ml-0">
            <div class="cassual-lbl">Cassual</div>
            <div class="vacasion-lbl">Vacasion</div>
            <div class="other-lbl">Other</div>
            <div class="special-lbl">Special</div>
            <div class="short-lbl">Short</div>
        </div>
        </div>
    </div>

    <h3>My Leave Requests</h3>
    <div class="row table-max-height-300">
        <!-- Leave Details -->
        <table class="table table-striped">
            <thead>
                <tr>
                <th scope="col">Date of Commencing Leave</th>
                <th scope="col">Type of Leave</th>
                <th scope="col">Number of Days</th>
                <th scope="col">Approval Status</th>
                <th scope="col">Approved Date if Approved</th> 
                </tr>
            </thead>
            <tbody>
                @if($leaves_status->isNotEmpty())
                @foreach($leaves_status as $leave)
                    <tr>
                    <td>{!! date('Y-m-d', strtotime($leave->start_date)) !!}</td>
                    <td>{{$leave->leaveType->type}} Leave</td>
                    <td>{{$leave->no_of_days}}</td>
                    @if($leave->status == 0)
                    <td>Pending</td>
                    @elseif($leave->status == 1)
                    <td>Approved</td>
                    @elseif($leave->status == 3)
                    <td>Forwarded To Registar</td>
                    @else
                    <td>Rejected</td>
                    @endif

                    @if($leave->approved_at != NULL)
                    <td>{!! date('Y-m-d', strtotime($leave->approved_at)) !!}</td>
                    @else
                    <td>-</td>
                    @endif
                    </tr>
                    @endforeach
                @else
                <tr><td class="td-bgcolor-white">No leaves</td></tr>
                @endif
            </tbody>
        </table>
    </div>
</div>
@endsection
