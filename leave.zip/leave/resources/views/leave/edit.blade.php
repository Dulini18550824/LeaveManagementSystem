@extends('layouts.app')
@section('content')

<div class="table-padding">

    @if(session()->has('message'))
        <div class="alert alert-danger">
            {{ session()->get('message') }}
        </div>
    @endif
    @if(session()->has('msg'))
        <div class="alert alert-success">
            {{ session()->get('msg') }}
        </div>
    @endif
    
    <h3>Edit Leave</h3>
    <table class="table table-striped">
    <thead>
        <tr>
        <th>Reason</th>
        <th>Date of commencing leave</th>
        <th>Date of resuming duties</th>
        <th>From</th>
        <th>To</th>
        <th></th>
        </tr>
    </thead>
    <tbody>
        @foreach($leaves as $leave)
        <tr>
            <td>{{$leave->reason}}</td>
            <td>{{\Carbon\Carbon::parse($leave->start_date)->format('j F, Y')}}</td>

            @if($leave->leave_type != 3)
            <td>{{\Carbon\Carbon::parse($leave->end_date)->format('j F, Y')}}</td>
            @else
            <td>-</td>
            @endif
            
            @if($leave->leave_type == 3)
            <td>{{\Carbon\Carbon::parse($leave->time_from)->format('g:i A')}}</td>
            <td>{{\Carbon\Carbon::parse($leave->time_to)->format('g:i A')}}</td>
            @else
            <td>-</td>
            <td>-</td>
            @endif

            @if($leave->leave_type == 1)
            <td>
                <a href="/leave/{{$leave->id}}" type="button" class="btn btn-success">Edit</a>
                <a href="/leave/{{$leave->id}}/delete" type="button" class="btn btn-danger">Delete</a>
            </td>
            @elseif($leave->leave_type == 3)
            <td>
                <a href="/leave/short-leave/{{$leave->id}}" type="button" class="btn btn-success">Edit</a>
                <a href="/leave/{{$leave->id}}/delete" type="button" class="btn btn-danger">Delete</a>
            </td>
            @elseif($leave->leave_type == 4)
            <td>
                <a href="/leave/other/{{$leave->id}}" type="button" class="btn btn-success">Edit</a>
                <a href="/leave/{{$leave->id}}/delete" type="button" class="btn btn-danger">Delete</a>
            </td>
            @elseif($leave->leave_type == 5)
            <td>
                <a href="/leave/special/{{$leave->id}}" type="button" class="btn btn-success">Edit</a>
                <a href="/leave/{{$leave->id}}/delete" type="button" class="btn btn-danger">Delete</a>
            </td>
            @endif

        </tr>
        @endforeach
        <tr>
    </tbody>
    </table>

</div>
@endsection