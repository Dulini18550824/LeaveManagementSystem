@extends('layouts.app')
@section('content')
<div class="container">
    @if(session()->has('message'))
        <div class="alert alert-danger">
            {{ session()->get('message') }}
        </div>
    @endif
    @if(session()->has('msg'))
        <div class="alert alert-success">
            {{ session()->get('msg') }}
        </div>
    @endif
</div>


<div class="table-padding">
    <h3>Manage Leave</h3>
    <table class="table table-striped">
    <thead>
        <tr>
        <th>Name</th>
        <th>Leave Type</th>
        <th>Reason</th>
        <th>Start Date</th>
        <th>End Date</th>
        <th>From</th>
        <th>To</th>
        <th>Working hours</th>
        <th>File</th>
        <th>Acting Name</th>
        <th>Acting Mobile No.</th>
        <th></th>
        <th></th>
        </tr>
    </thead>
    <tbody>
        @foreach($leaves as $leave)
        <tr>
            <td>{{$leave->user->name}}</td>
            @if($leave->leave_type == 1 || $leave->leave_type == 2)
            <td>Normal</td>
            @elseif($leave->leave_type == 3)
            <td>Short</td>
            @elseif($leave->leave_type == 4)
            <td>Other</td>
            @elseif($leave->leave_type == 5)
            <td>Special</td>
            @endif
            <td>{{$leave->reason}}</td>
            <td>{{\Carbon\Carbon::parse($leave->start_date)->format('j F, Y')}}</td>
            <td>{{\Carbon\Carbon::parse($leave->end_date)->format('j F, Y')}}</td>
            @if($leave->leave_type == 3)
            <td>{{$leave->time_from}}</td>
            <td>{{$leave->time_to}}</td>
            <td>{{$leave->user->work_from}} - {{$leave->user->work_to}}</td>
            <td></td>
            <td></td>
            <td></td>
            @else
            <td></td>
            <td></td>
            <td></td>
            <td>{{$leave->file_upload}}</td>
            <td>{{$leave->acting->name}}</td>
            <td>{{$leave->acting->mobile_no}}</td>
            @endif

            <form method="POST" action="{{ url('leave/'.$leave->id.'/approve') }}" >
                @csrf
                <td><button type="submit" class="btn btn-success">Approve</button></td>
            </form>

            <form method="POST" action="{{action('LeaveController@rejectLeave', $leave->id)}}">
                @csrf
                <td><button type="submit" class="btn btn-danger">Reject</button></td>
            </form>
        </tr>
        @endforeach
        <tr>
    </tbody>
    </table>

</div>
@endsection