@extends('layouts.app')
@section('content')
<leave-manage :leaves="{{ json_encode($leaves) }}" :auth="{{ $auth_user }}"></leave-manage>
@endsection