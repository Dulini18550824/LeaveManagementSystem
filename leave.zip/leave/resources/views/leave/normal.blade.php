@extends('layouts.app')
@section('content')
<div class="container">
<div class="card">
  <div class="card-header">
    Leave Application
  </div>
  <div class="card-body">
      <form method="POST" action="{{action('LeaveController@normalLeave')}}" enctype="multipart/form-data">
      @csrf
      @if(session()->has('message'))
          <div class="alert alert-danger">
              {{ session()->get('message') }}
          </div>
      @endif
      @if(session()->has('msg'))
          <div class="alert alert-success">
              {{ session()->get('msg') }}
          </div>
      @endif
          <div class="row mb-4">

            <div class="col">
                <label for="start_date">Date of commencing leave<label class="error-msg">*</label></label>
                <input type="date" min="{{Carbon\Carbon::today()->format('Y-m-d')}}" class="form-control" placeholder="Optional" id="start_date" name="start_date" required 
                value="{{ old('start_date') }}{{$leave!=NULL ? Carbon\Carbon::parse($leave->start_date)->format('Y-m-d'):''}}" onchange="getDiff();">
                @error('start_date')
                    <span class="error-msg" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
    
            <div class="col">
                <label for="end_date">Date of resuming duties<label class="error-msg">*</label></label>
                <input type="date" min="{{Carbon\Carbon::today()->format('Y-m-d')}}" class="form-control" placeholder="Optional" id="end_date" name="end_date" required 
                value="{{ old('end_date') }}{{$leave!=NULL ? Carbon\Carbon::parse($leave->end_date)->format('Y-m-d'): ''}}" onchange="getDiff();">
                @error('end_date')
                    <span class="error-msg" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
          </div>
    
          <div class="row mb-4">
                <div class="col">
                  <label for="no_of_days">No. of days leave apply for
                      <label class="error-msg">* @if($earned_leave!=NULL)(You have {{$earned_leave}} remaining leaves) @endif</label>
                    </label>
                  <input type="number" step=".1" class="form-control" placeholder="Eg: 0.5 - Half day, 1 - Full day" id="no_of_days" name="no_of_days" value="{{ old('no_of_days') }}{{$leave!=NULL ? $leave->no_of_days : ''}}" >
                  @error('no_of_days')
                      <span class="error-msg" role="alert">
                          <strong>{{ $message }}</strong>
                      </span>
                  @enderror
              </div>
    
              <div class="col">
                  <label for="reason">Reason for leave<label class="error-msg">*</label></label>
                  <input type="text" class="form-control" placeholder="" name="reason" value="{{ old('reason') }}{{$leave!=NULL ? $leave->reason : ''}}">
                  @error('reason')
                      <span class="error-msg" role="alert">
                          <strong>{{ $message }}</strong>
                      </span>
                  @enderror
              </div>

          </div>
    
          <div class="row mb-4">
              <div class="col">
                  <label for="file_upload">File Upload (Please fill this field if you apply leave more than 3 days)</label>
                  <input type="file" class="form-control" placeholder="Optional" name="file_upload" value="{{ old('file_upload') }}{{$leave!=NULL ? $leave->file_upload : ''}}">
                  @error('file_upload')
                      <span class="error-msg" role="alert">
                          <strong>{{ $message }}</strong>
                      </span>
                  @enderror
              </div>
    
              <div class="col">
                  <label for="acting_user_id">Acting Person's Name<label class="error-msg">*</label></label>
                  <select name="acting_user_id" class="form-control" required value="{{ old('acting_user_id') }}{{$leave!=NULL ? $leave->acting->name : ''}}">
                      @foreach($users as $user)
                      <option value="{{$user->id}}">{{$user->name}}</option>>
                      @endforeach
                  </select>
                  <!-- <input type="text" class="form-control" placeholder="" name="acting_user_id" required value="{{ old('acting_user_id') }}"> -->
                  @error('acting_user_id')
                      <span class="error-msg" role="alert">
                          <strong>{{ $message }}</strong>
                      </span>
                  @enderror
              </div>
          </div>

          @if($leave!=NULL)
          <input type="hidden" name="leave_id" value="{{$leave->id}}">
          @endif
    
          <button type="submit" class="btn btn-primary" style="float: right;">Submit</button>
    
      </form>
    
    </div>
    </div>
</div>

<script>

    var holidays = @json($holidays);

    function isWeekDay(day) {
        if(day.getDay() == 6 || day.getDay() == 0) {
            return true;
        } else {
            return false;
        }
    }

    function valildateHolidayCount(start, end) {
        var count = 0;
        var holi_count = 0;

        for (var d = start; d <= end; d.setDate(d.getDate() + 1)) {
            if (!isWeekDay( new Date(d) )) {
                var c_day = '';
                if (d.getDate().toString() < 10) {
                    var c_day = d.getFullYear().toString() + '-' + String(d.getMonth() + 1) + '-0' + d.getDate().toString();
                } else {
                    var c_day = d.getFullYear().toString() + '-' + String(d.getMonth() + 1) + '-' + d.getDate().toString();
                }
                
                holidays.forEach(function (index) { 
                    if ( index.date == c_day ) {
                        holi_count++;
                        return false;
                    }
                });
                count++;
            }
            
        }
        return count - holi_count;
    }

   
    function getDiff() { 
        var start_date = document.getElementById('start_date');
        var end_date = document.getElementById('end_date');
        var diff = 0;

        if (start_date.value != null && end_date.value != null) {
            var start = new Date(start_date.value);
            var end = new Date(end_date.value);

            diff = valildateHolidayCount(start, end) - 1;
            if (diff <= 45) {
                document.getElementById('no_of_days').value = diff;
            } else {
                document.getElementById('no_of_days').value = 45;
            }
        }
    }
</script>

@endsection