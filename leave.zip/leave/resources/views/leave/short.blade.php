@extends('layouts.app')
@section('content')
<div class="container">
    <div class="card">
        <div class="card-header">
            Short Leave Application
        </div>
        <div class="card-body">
            <form method="POST" action="{{action('LeaveController@shortLeave')}}">
            @csrf
            @if(session()->has('message'))
                <div class="alert alert-danger">
                    {{ session()->get('message') }}
                </div>
            @endif
            @if(session()->has('msg'))
                <div class="alert alert-success">
                    {{ session()->get('msg') }}
                </div>
            @endif
                <div class="row mb-4">

                    <div class="col">
                        <label for="start_date">Date<label class="error-msg">*</label></label>
                        <input type="date" min="{{Carbon\Carbon::today()->format('Y-m-d')}}" class="form-control" placeholder="Optional" name="start_date" required 
                        value="{{ old('start_date') }}{{$leave!=NULL && property_exists($leave, 'start_date') ? Carbon\Carbon::parse($leave->start_date)->format('Y-m-d'):''}}">
                        @error('start_date')
                            <span class="error-msg" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>

                    <div class="col">
                        <label for="reason">Reason<label class="error-msg">*</label></label>
                        <input type="text" class="form-control" placeholder="" name="reason" value="{{ old('reason') }}">
                        @error('reason')
                            <span class="error-msg" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>

                    <div class="col">
                        <label for="time_from">Time from<label class="error-msg">*</label></label>
                        <input type="time" class="form-control" name="time_from" required 
                        value="{{ old('time_from') }}{{$leave!=NULL && property_exists($leave, 'start_date') ? Carbon\Carbon::parse($leave->time_from)->format('H:i'):''}}" min="{{auth()->user()->work_from}}">
                        @error('time_from')
                            <span class="error-msg" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>

                    <div class="col">
                        <label for="time_to">Time to<label class="error-msg">*</label></label>
                        <input type="time" class="form-control" placeholder="Optional" name="time_to" required 
                        value="{{ old('time_to') }}{{$leave!=NULL && property_exists($leave, 'start_date') ? Carbon\Carbon::parse($leave->time_to)->format('H:i'):''}}" max="{{auth()->user()->work_to}}">
                        @error('time_to')
                            <span class="error-msg" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>

                </div>
                
                @if($leave!=NULL && property_exists($leave, 'start_date'))
                <input type="hidden" name="leave_id" value="{{$leave->id}}">
                @endif

                <button type="submit" class="btn btn-primary" style="float: right;">Submit</button>

            </form>
        </div>
    </div>
    </div>
@endsection