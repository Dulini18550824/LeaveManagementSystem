<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <div class="card">
        <div class="card-header">
        Report
        </div>
        <div class="card-body">
            <h5 class="card-title">Balance Leave Report</h5>

            <!-- Employee Details -->
            <div class="mb-4">
                <div><label class="lbl-width-130">Employee Name:</label>{{$user->name}}</div>
                <div><label class="lbl-width-130">E-mail Address:</label>{{$user->email}}</div>
                <div><label class="lbl-width-130">Contact Number:</label>0{{$user->mobile_no}}</div> 
                <div><label class="lbl-width-130">EPF Number:</label>{{$user->epf_no}}</div> 
                <div><label class="lbl-width-130">Designation:</label>{{$user->designation}}</div> 
                <div><label class="lbl-width-130">Team:</label>{{$user->team->name}}</div>
                <div><label class="lbl-width-130">Raport Date:</label>{{Carbon\Carbon::now()->isoFormat('YYYY-MM-DD')}}</div>
            </div>

            <!-- Leave Details -->
            <div class="table-max-height-300">
                <table class="table table-striped">
                    <thead>
                        <tr>
                        <th scope="col">Type of Leave</th>
                        <th scope="col">Number of Leave Allocated for Year</th>
                        <th scope="col">Number of Leave Taken</th>
                        <th scope="col">Balance of Leave</th> 
                        </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>Casual Leave</td>
                        <td>21</td>
                        <td>{{$leaves['casual']}}</td>
                        <td>{{21 - $leaves['casual']}}</td>
                        </tr>
                        <tr>
                        <td>Vacation Leave</td>
                        <td>24</td>
                        <td>{{$leaves['vacation']}}</td>
                        <td>{{24 - $leaves['vacation']}}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        </div>
    </div>
</body>
</html>