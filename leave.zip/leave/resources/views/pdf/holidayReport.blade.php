<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Holiday Report</title>
</head>
<body>
    <div class="container">
        <h3>Holiday Report</h3>
        Year: 2021 
        <table class="table table-striped">
            <thead>
                <tr>
                <th scope="col">Date</th>
                <th scope="col">Holoday</th>
                </tr>
            </thead>
            <tbody>
                @foreach($holidays as $holiday)
                <tr>
                <td>{{$holiday->date}}</td>
                <td>{{$holiday->name}}</td>
                </tr>
                @endforeach
            </tbody>
            </table>
    </div>
</body>
</html>