<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="mb-4">
        <div><label class="lbl-width-130">Name:</label>{{$leave->user->name}}</div>
        <div><label class="lbl-width-130">Email Address:</label>{{$leave->user->email}}</div>
        <div><label class="lbl-width-130">Contact Number:</label>0{{$leave->user->mobile_no}}</div>
        <div><label class="lbl-width-130">Designation:</label>{{$leave->user->designation}}</div> 
        <div><label class="lbl-width-130">First Appointment Date:</label>{{$leave->user->first_appointment}}</div>
        <div><label class="lbl-width-130">Working Hours:</label>{{$leave->user->work_from}} - {{$leave->user->work_to}}</div>
        <div><label class="lbl-width-130">Number of days leave apply for:</label>{{$leave->no_of_days}}</div>
        <div><label class="lbl-width-130">Reason for leave:</label>{{$leave->reason}}</div>
        <div><label class="lbl-width-130">Date of comencing leave:</label>{{$leave->start_date}}</div>
        <div><label class="lbl-width-130">Date of resuming leave:</label>{{$leave->end_date}}</div>
        <div><label class="lbl-width-130">Date of leave apply:</label>{{Date('Y-m-d')}}</div>

    </div>
</body>
</html>