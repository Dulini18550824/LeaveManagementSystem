@extends('layouts.app')

@section('content')
<div class="container">
    <h3>Holiday Report</h3>
    Year: 2021 
    <table class="table table-striped">
        <thead>
            <tr>
            <th scope="col">Date</th>
            <th scope="col">Holoday</th>
            </tr>
        </thead>
        <tbody>
            @foreach($holidays as $holiday)
            <tr>
            <td>{{$holiday->date}}</td>
            <td>{{$holiday->name}}</td>
            </tr>
            @endforeach
        </tbody>
        </table>
    <a class="btn btn-primary f-r m-1" href="/reports/holidays-pdf">Download</a>
</div>
@endsection