@extends('layouts.app')

@section('content')
<div class="container">
    <div class="card">
    <div class="card-header">
    Report
    </div>
    <div class="card-body">
        <h5 class="card-title">Leave Status Report</h5>

        <!-- Employee Details -->
        <div class="mb-4">
            <div><label class="lbl-width-130">Employee Name:</label>{{$user->name}}</div>
            <div><label class="lbl-width-130">E-mail Address:</label>{{$user->email}}</div>
            <div><label class="lbl-width-130">Contact Number:</label>0{{$user->mobile_no}}</div> 
            <div><label class="lbl-width-130">EPF Number:</label>{{$user->epf_no}}</div> 
            <div><label class="lbl-width-130">Designation:</label>{{$user->designation}}</div> 
            <div><label class="lbl-width-130">Team:</label>{{$user->team->name}}</div>
            <div><label class="lbl-width-130">Raport Date:</label>{{Carbon\Carbon::now()->isoFormat('YYYY-MM-DD')}}</div>
        </div>

        <!-- Leave Details -->
        <div class="table-max-height-300">
            <table class="table table-striped">
                <thead>
                    <tr>
                    <th scope="col">Date of Commencing Leave</th>
                    <th scope="col">Type of Leave</th>
                    <th scope="col">Number of Days</th>
                    <th scope="col">Approval status</th>
                    <th scope="col">Approved date if approved</th> 
                    </tr>
                </thead>
                <tbody>
                    @if($leaves->isNotEmpty())
                        @foreach($leaves as $leave)
                        <tr>
                        <td>{!! date('Y-m-d', strtotime($leave->start_date)) !!}</td>
                        <td>{{$leave->leaveType->type}} Leave</td>
                        <td>{{$leave->no_of_days}}</td>
                        @if($leave->status == 0)
                        <td>Pending</td>
                        @elseif($leave->status == 1)
                        <td>Approved</td>
                        @else
                        <td>Rejected</td>
                        @endif
    
                        @if($leave->approved_at != NULL)
                        <td>{!! date('Y-m-d', strtotime($leave->approved_at)) !!}</td>
                        @else
                        <td>-</td>
                        @endif
                        </tr>
                        @endforeach
                    @else
                    <tr><td class="td-bgcolor-white">No leaves</td></tr>
                    @endif
                </tbody>
            </table>
        </div>

        <a class="btn btn-primary f-r m-1" href="/reports/leave-status-pdf">Download</a>
    </div>
    </div>
</div>
@endsection