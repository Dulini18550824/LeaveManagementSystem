@extends('layouts.app')

@section('content')
<div class="container">
    <div class="card">
    <div class="card-header">
    Report
    </div>
    <div class="card-body">
        <h5 class="card-title">Short Leave Detail Report</h5>

        <!-- Employee Details -->
        <div class="mb-4">
            <div><label class="lbl-width-130">Employee Name:</label>{{$user->name}}</div>
            <div><label class="lbl-width-130">E-mail Address:</label>{{$user->email}}</div>
            <div><label class="lbl-width-130">Contact Number:</label>0{{$user->mobile_no}}</div> 
            <div><label class="lbl-width-130">EPF Number:</label>{{$user->epf_no}}</div> 
            <div><label class="lbl-width-130">Designation:</label>{{$user->designation}}</div> 
            <div><label class="lbl-width-130">Team:</label>{{$user->team->name}}</div>
            <div><label class="lbl-width-130">Raport Date:</label>{{Carbon\Carbon::now()->isoFormat('YYYY-MM-DD')}}</div>
        </div>

        <!-- Leave Details -->
        <div class="table-max-height-300">
            <table class="table table-striped">
                <thead>
                    <tr>
                    <th scope="col">Date</th>
                    <th scope="col">Reason</th>
                    <th scope="col">Time From</th> 
                    <th scope="col">Time To</th> 
                    </tr>
                </thead>
                <tbody>
                    @if($leaves->isNotEmpty())
                        @foreach($leaves as $leave)
                        <tr>
                        <td>{!! date('Y-m-d', strtotime($leave->start_date)) !!}</td>
                        <td>{{$leave->reason}}</td>
                        <td>{{ Carbon\Carbon::parse($leave->time_from)->format('h:i A') }}</td>
                        <td>{{ Carbon\Carbon::parse($leave->time_to)->format('h:i A') }}</td>
                        </tr>
                        @endforeach
                    @else
                    <tr><td class="td-bgcolor-white">No leaves</td></tr>
                    @endif
                </tbody>
            </table>
        </div>
        
        @if($id == NULL)
        <a class="btn btn-primary f-r m-1" href="/reports/shortLeave-detail-pdf">Download</a>
        @else
        <a class="btn btn-primary f-r m-1" href="/reports/shortLeave-detail-pdf/{{$id}}">Download</a>
        @endif
    </div>
    </div>
</div>
@endsection