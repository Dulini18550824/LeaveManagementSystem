@extends('layouts.app')

@section('content')
<div class="container">
    <label for="">Employee Name: {{$user_name}}</label>
    <user-calendar :data='@json($data)'></user-calendar>
</div>
@endsection