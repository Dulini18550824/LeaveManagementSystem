@extends('layouts.app')

@section('content')
<div class="container">
    <div>
        <h5 class="card-title">Employee Calendars</h5>

        <!-- Leave Details -->
        <div class="table-max-height-300">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col" class="align-top">EPF Number</th>
                        <th scope="col" class="align-top">Employee Name</th>
                        <th scope="col">Team</th>
                        <th scope="col"></th> 
                    </tr>
                </thead>
                <tbody>
                    @foreach($users as $user)
                    <tr>
                        <td>{{$user->epf_no}}</td>
                        <td>{{$user->name}}</td>
                        <td>{{$user->team->name}}</td>
                        <td><a class="btn btn-primary" href="/calender/user/{{$user->id}}">View Calendar</a></td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

@endsection