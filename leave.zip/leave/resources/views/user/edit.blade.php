@extends('layouts.app')

@section('content')

@if(session()->has('success'))
    <div class="alert alert-success alert-dismissible fade show">
        {{ session()->get('success') }}
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
@endif

<div class="row">
  <div class="col-lg-15 mx-auto">
    <div class="card">
        <div class="card-header">
           Edit : {{$user->name}}
        </div>
        <div class="card-body">
            <form method="POST" action="{{ route('admin.users.update',$user->id) }}">
                @method('PUT')
                @csrf
                <div class="row">
                <div class="col-md-6">
                    <div class="form-group row">
                        <label for="name" class="col-md-4 col-form-label text-md-right">{{ __('Name') }}
                        <label class="error-msg">*</label>
                        </label>

                        <div class="col-md-8">
                            <input id="name" type="text" class="form-control @error('name') is-invalid @enderror" name="name" value="{{ $user->name }}" required autocomplete="name" autofocus>

                            @error('name')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="email" class="col-md-4 col-form-label text-md-right">{{ __('E-Mail Address') }}
                            <label style="color:red;">*</label>
                        </label>

                        <div class="col-md-8">
                            <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ $user->email }}" required autocomplete="email">

                            @error('email')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="epf_no" class="col-md-4 col-form-label text-md-right">{{ __('EPF No') }}
                            <label style="color:red;">*</label>
                        </label>

                        <div class="col-md-8">
                            <input id="epf_no" type="text" class="form-control @error('epf_no') is-invalid @enderror" name="epf_no" value="{{ $user->epf_no }}" required autocomplete="epf_no" autofocus>

                            @error('epf_no')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="designation" class="col-md-4 col-form-label text-md-right">{{ __('Designation') }}
                            <label style="color:red;">*</label>
                        </label>

                        <div class="col-md-8">
                            <input id="designation" type="text" class="form-control @error('designation') is-invalid @enderror" name="designation" value="{{ $user->designation }}" required autocomplete="designation" autofocus>

                            @error('designation')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="password" class="col-md-4 col-form-label text-md-right">{{ __('Password') }}
                            <label style="color:red;">*</label>
                        </label>

                        <div class="col-md-8">
                            <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" autocomplete="new-password">

                            @error('password')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>
                </div>

                <div class="col-md-6">

                    <div class="form-group row">
                        <label for="team_id" class="col-md-4 col-form-label text-md-right">{{ __('Team') }}</label>

                        <div class="col-md-8">
                            <select name="team_id" id="team" class="form-control">
                                <option value="0"></option>
                                <option value="1" {{ ($user->team_id == 1) ? 'selected' : '' }}>Software Development</option>
                                <option value="2" {{ ($user->team_id == 2) ? 'selected' : '' }}>Web Development</option>
                                <option value="3" {{ ($user->team_id == 3) ? 'selected' : '' }}>IT Infrastructure & Network</option>
                                <option value="4" {{ ($user->team_id == 4) ? 'selected' : '' }}>Instructors</option>
                                <option value="5" {{ ($user->team_id == 5) ? 'selected' : '' }}>IT Officers</option>
                                <option value="6" {{ ($user->team_id == 6) ? 'selected' : '' }}>AV Officers</option>
                                <option value="7" {{ ($user->team_id == 7) ? 'selected' : '' }}>Clarical</option>
                                <option value="8" {{ ($user->team_id == 8) ? 'selected' : '' }}>Other</option>
                            </select>

                            @error('team_id')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="first_appointment" class="col-md-4 col-form-label text-md-right">{{ __('Appointment date') }}
                            <label style="color:red;">*</label>
                        </label>

                        <div class="col-md-8">
                            <input id="first_appointment" type="date" class="form-control @error('first_appointment') is-invalid @enderror" name="first_appointment" value="{{ $user->first_appointment }}" required autocomplete="first_appointment" autofocus>

                            @error('first_appointment')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="mobile_no" class="col-md-4 col-form-label text-md-right">{{ __('Mobile No') }}
                            <label style="color:red;">*</label>
                        </label>

                        <div class="col-md-8">
                            <input id="mobile_no" type="text" class="form-control @error('mobile_no') is-invalid @enderror" name="mobile_no" value="{{ $user->mobile_no }}" required autocomplete="mobile_no" autofocus placeholder="07xxxxxxxx">

                            @error('mobile_no')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="work_from" class="col-md-4 col-form-label text-md-right">{{ __('Wrok from') }}
                            <label style="color:red;">*</label>
                        </label>

                        <div class="col-md-8">
                            <input id="work_from" type="time" class="form-control @error('work_from') is-invalid @enderror" name="work_from" value="{{ $user->work_from }}" required autocomplete="work_from" autofocus>

                            @error('work_from')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="work_to" class="col-md-4 col-form-label text-md-right">{{ __('Wrok to') }}
                            <label style="color:red;">*</label>
                        </label>

                        <div class="col-md-8">
                            <input id="work_to" type="time" class="form-control @error('work_to') is-invalid @enderror" name="work_to" value="{{ $user->work_to }}" required autocomplete="work_to" autofocus>

                            @error('work_to')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row mb-0">
                        <div class="col-md-12 offset-md-8">
                            <button type="submit" class="btn btn-primary">
                                {{ __('Update') }}
                            </button>
                        </div>
                    </div>
                </div>
                </div>
            </form>
        </div>
    </div>
</div>
</div>

@endsection