@extends('layouts.app')

@section('content')
<div class="container">
    <div class="table-padding">
            <h3>Employee Profiles</h3>
            <table class="table table-striped">
            <thead>
                <tr>
                    <th>EPF No.</th>
                    <th>Name</th>
                    <th>Team</th>
                    <th></th>
                </tr>
                @foreach($users as $user)
                <tr>
                    <th>{{$user->epf_no}}</th>
                    <th>{{$user->name}}</th>
                    <th>{{$user->team->name}}</th>
                    <th><a href="/profile/{{$user->id}}" class="btn btn-primary">View Profile</a></th>
                </tr>
                @endforeach
            </thead>
         </table>
    </div>
</div>
@endsection