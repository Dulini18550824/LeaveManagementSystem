@extends('layouts.app')

@section('content')

@if(session()->has('success'))
    <div class="alert alert-success alert-dismissible fade show">
        {{ session()->get('success') }}
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
@endif

@if(session()->has('error_msg'))
    <div class="alert alert-danger alert-dismissible fade show">
        {{ session()->get('error_msg') }}
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
@endif


<div class="row">
  <div class="col-lg-15 mx-auto">
    <div class="card">
        <div class="card-header">
            Users
        </div>
        <div class="card-body">
            <!-- Users Details -->
            <div class="mb-4">
                <table class="table table-bordered mb-5">
                    <thead>
                        <tr class="table-success">
                            <th scope="col">Name</th>
                            <th scope="col">Email</th>
                            <th scope="col">User Type</th>
                            <th scope="col">EPF No</th>
                            <th scope="col">Designation</th>
                            <th scope="col">Team</th>
                            <th scope="col">Phone No</th>
                            <th scope="col">Verify</th>
                            <th scope="col">Manage</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($users as $data)
                        <tr>
                            <th scope="row">{{ $data->name }}</th>
                            <td>{{ $data->email }}</td>
                            <td>
                                @if($data->user_type == 1) <p>HOD</p>
                                @elseif($data->user_type == 2) <p>ACTING</p>
                                @elseif($data->user_type == 3) <p>EMPLOYEE</p>
                                @elseif($data->user_type == 4) <p>REGISTAR</p>
                                @endif
                            </td>
                            <td>{{ $data->epf_no }}</td>
                            <td>{{ $data->designation }}</td>
                            @if(!empty($data->team))
                            <td>{{ $data->team->name }}</td>
                            @else
                            <td>None</td>
                            @endif
                            @if(!empty($data->mobile_no))
                            <td>{{ $data->mobile_no }}</td>
                            @else
                            <td>None</td>
                            @endif
                            <td>
                                @if($data->is_verified === "true")
                                 <p>Verified</p>
                                @else
                                 <a href="{{ route('admin.users.verify', $data->id) }}" class="btn btn-primary">Verify</a>
                                @endif
                                </td>
                            <td>
                                <a href="{{ route('admin.users.edit', $data->id) }}" class="btn btn-primary">Edit</a>
                                <a href="{{ route('admin.users.delete', $data->id) }}" class="btn btn-danger">Delete</a>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>

                <div class="d-flex justify-content-center">
                    {!! $users->links() !!}
                </div>
            </div>
        </div>
    </div>
</div>
</div>

@endsection