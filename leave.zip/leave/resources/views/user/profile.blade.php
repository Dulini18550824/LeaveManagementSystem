@extends('layouts.app')

@section('content')
<div class="container">
    <div class="card">
        <div class="card-header">
            Profile
        </div>
        <div class="card-body">
            <!-- Employee Details -->
            <div class="mb-4">
                <div><label class="lbl-width-165">Name:</label>{{$user->name}}</div>
                <div><label class="lbl-width-165">E-mail Address:</label>{{$user->email}}</div>
                <div><label class="lbl-width-165">Contact Number:</label>0{{$user->mobile_no}}</div> 
                <div><label class="lbl-width-165">EPF Number:</label>{{$user->epf_no}}</div> 
                <div><label class="lbl-width-165">Designation:</label>{{$user->designation}}</div> 
                <div><label class="lbl-width-165">Team:</label>{{$user->team->name}}</div>
                <div><label class="lbl-width-165">First Appointment Date:</label>{{$user->first_appointment}}</div>
                <div><label class="lbl-width-165">Working Hours:</label>
                    {{ Carbon\Carbon::parse($user->work_from)->format('h:i A') }} - {{Carbon\Carbon::parse($user->work_to)->format('h:i A')}}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection