<?php

use Illuminate\Support\Facades\Route;
use App\Mail\LeaveApprovedMail;
use App\Mail\ApprovedLeaveMail;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
})->name('frontpage');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/usernotverified', function() { return view('errors/usernotverified'); })->name('errors.usernotverified');
Route::get('/dashboard', 'UserController@dashboard')->name('dashboard');

Route::middleware(['auth', 'userverify'])->group(function () {
    Route::get('/leave/select', 'LeaveController@select');
    
    //admin routes
    Route::get('/admin/users/', 'UserController@index')->name('admin.index');
    Route::get('/admin/users/edit/{id}', 'UserController@edit')->name('admin.users.edit');
    Route::put('/admin/users/update/{id}', 'UserController@update')->name('admin.users.update');
    Route::get('/admin/users/delete/{id}', 'UserController@delete')->name('admin.users.delete');
    Route::get('/admin/users/verify/{id}', 'UserController@verify')->name('admin.users.verify');
    Route::get('/admin/users/create/', 'UserController@create')->name('admin.users.create');
    Route::post('/admin/users/store/', 'UserController@store')->name('admin.users.store');


    // shortLeaveView
    Route::get('/leave/short-leave/{id?}', 'LeaveController@shortLeaveView');
    Route::post('/leave/short-leave', 'LeaveController@shortLeave');
    
    // specialLeaveView
    Route::get('/leave/special/{id?}', 'LeaveController@specialLeaveView');
    Route::post('/leave/special-leave', 'LeaveController@specialLeave');
    
    // otherLeaveView
    Route::get('/leave/other/{id?}', 'LeaveController@otherLeaveView');
    Route::post('/leave/other-leave', 'LeaveController@otherLeave');
    
    // ManageLeave
    Route::get('/leave/edit/{type}', 'LeaveController@editLeaveView');
    Route::get('/leave/manage', 'LeaveController@manageLeaveView')->name('leave.manage');
    Route::post('/leave/{id}/approve', 'LeaveController@approveLeave');
    Route::post('/leave/{id}/reject', 'LeaveController@rejectLeave');
    Route::post('/leave/{id}/forward', 'LeaveController@forwardLeave');
    Route::post('/leave/user/{id}/warning', 'LeaveController@sendWarningMail');
    
    // Delete Leave
    Route::get('/leave/{id}/delete', 'LeaveController@deleteLeave');
    
    // normalLeave
    Route::get('/leave/{id?}', 'LeaveController@normalLeaveView');
    Route::post('/leave/normal-leave', 'LeaveController@normalLeave');
    
    // Make Acting
    Route::get('/acting', 'ActingController@index');
    Route::post('/user/{id}/make-acting', 'ActingController@makeActing');
    Route::post('/user/{id}/remove-acting', 'ActingController@removeActing');
    Route::get('/user/accept-acting', 'ActingController@acceptActing')->name('accept-acting');
    Route::get('/user/reject-acting', 'ActingController@rejectActing')->name('reject-acting');


    // Reports
    Route::get('/reports', 'ReportController@index');
    Route::get('/reports/leave-detail/{id?}', 'ReportController@leaveDetail');
    Route::get('/reports/shortLeave-detail/{id?}', 'ReportController@shortLeaveDetail');
    Route::get('/reports/Balance-leave', 'ReportController@BalanceLeave');
    Route::get('/reports/leave-status', 'ReportController@leaveStatus');
    Route::get('/reports/holiday', 'ReportController@holiday');

    Route::get('/reports/all/leave-balance', 'ReportController@allLeaveBalance');
    Route::get('/reports/all/leave-summary', 'ReportController@allLeaveSummary');
    Route::get('/reports/all/leave-detail/{type}', 'ReportController@allLeaveDetail');


    // Downloads
    Route::get('/generate-pdf','PDFController@generatePDF');
    Route::get('/reports/leave-detail-pdf/{id?}', 'PDFController@leaveDetailDownload');
    Route::get('/reports/shortLeave-detail-pdf/{id?}', 'PDFController@shortLeaveDetailDownload');
    Route::get('/reports/balance-leave-pdf', 'PDFController@balanceLeaveDownload');
    Route::get('/reports/leave-status-pdf','PDFController@leaveStatusDownload');
    Route::get('/reports/holidays-pdf','PDFController@holidayDownload');

    Route::get('/reports/all/leave-balance-pdf', 'PDFController@allLeaveBalanceDownload');
    Route::get('/reports/all/leave-summary-pdf', 'PDFController@allLeaveSummaryDownload');
    Route::get('/special-leave/{id}/download', 'PDFController@specialLeaveFormDownload');


    // Calendar
    Route::get('/calender/leave/{id?}', 'CalendarController@getLeave');
    Route::get('/calender/user/{id}', 'CalendarController@getuserWiseLeave');
    Route::get('/view-calendars', 'CalendarController@usersList');

    // Profile
    Route::get('/profile/{id?}', 'UserController@profile');
    Route::get('/emp-profile', 'UserController@empProfile');
});


