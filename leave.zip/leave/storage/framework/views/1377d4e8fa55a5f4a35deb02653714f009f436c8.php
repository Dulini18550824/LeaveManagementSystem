

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
    <div class="card-header">
    Report
    </div>
    <div class="card-body">
        <h5 class="card-title">Leave Balance Report</h5>

        <div class="mb-4">
            <div><label class="lbl-width-130">User:</label>HOD</div>
            <div><label class="lbl-width-130">Raport Date:</label><?php echo e(Carbon\Carbon::now()->isoFormat('YYYY-MM-DD')); ?></div>
        </div>

        <!-- Leave Details -->
        <div class="table-max-height-300">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col" rowspan="2" class="align-top">EPF Number</th>
                        <th scope="col" rowspan="2" class="align-top">Employee Name</th>
                        <th scope="col" colspan="2">Number of Leave Allocated for Year</th>
                        <th scope="col" colspan="2">Number of Leave Taken</th>
                        <th scope="col" colspan="2">Balance of Leave</th> 
                    </tr>
                    <tr>
                        <th scope="col">Casual</th>
                        <th scope="col">Vacation</th>
                        <th scope="col">Casual</th>
                        <th scope="col">Vacation</th>
                        <th scope="col">Casual</th>
                        <th scope="col">Vacation</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(!empty($user_leaves)): ?>
                    <?php $__currentLoopData = $user_leaves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user_leave['epf_no']); ?></td>
                        <td><?php echo e($user_leave['user_name']); ?></td>
                        <td>21</td>
                        <td>24</td>
                        <td><?php echo e($user_leave['cassual_count']); ?></td>
                        <td><?php echo e($user_leave['vacasion_count']); ?></td>
                        <td><?php echo e(21 - $user_leave['cassual_count']); ?></td>
                        <td><?php echo e(24 - $user_leave['vacasion_count']); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <tr><td class="td-bgcolor-white">No records</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <a class="btn btn-primary f-r" href="/reports/all/leave-balance-pdf">Download</a>
    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Laravel Projects\Ongoing\Project_Leave Management System\leave_manage\resources\views/report/all_leave_balance.blade.php ENDPATH**/ ?>