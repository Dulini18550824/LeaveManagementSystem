

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-header">
            Profile
        </div>
        <div class="card-body">
            <!-- Employee Details -->
            <div class="mb-4">
                <div><label class="lbl-width-165">Name:</label><?php echo e($user->name); ?></div>
                <div><label class="lbl-width-165">E-mail Address:</label><?php echo e($user->email); ?></div>
                <div><label class="lbl-width-165">Contact Number:</label>0<?php echo e($user->mobile_no); ?></div> 
                <div><label class="lbl-width-165">EPF Number:</label><?php echo e($user->epf_no); ?></div> 
                <div><label class="lbl-width-165">Designation:</label><?php echo e($user->designation); ?></div> 
                <div><label class="lbl-width-165">Team:</label><?php echo e($user->team->name); ?></div>
                <div><label class="lbl-width-165">First Appointment Date:</label><?php echo e($user->first_appointment); ?></div>
                <div><label class="lbl-width-165">Working Hours:</label>
                    <?php echo e(Carbon\Carbon::parse($user->work_from)->format('h:i A')); ?> - <?php echo e(Carbon\Carbon::parse($user->work_to)->format('h:i A')); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\leave\resources\views/user/profile.blade.php ENDPATH**/ ?>