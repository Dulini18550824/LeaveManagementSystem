<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div class="container">
    <div class="card">
    <div class="card-header">
    Report
    </div>
    <div class="card-body">
        <h5 class="card-title">Leave Summary Report</h5>

        <div class="mb-4">
            <div><label class="lbl-width-130">User:</label>HOD</div>
            <div><label class="lbl-width-130">Raport Date:</label><?php echo e(Carbon\Carbon::now()->isoFormat('YYYY-MM-DD')); ?></div>
        </div>

        <!-- Leave Details -->
        <div class="table-max-height-300">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col" rowspan="2" class="align-top">EPF Number</th>
                        <th scope="col" rowspan="2" class="align-top">Employee Name</th>
                        <th scope="col" rowspan="2" class="align-top">Employee Designation</th>
                        <th scope="col" rowspan="2" class="align-top">Employee Team</th>
                        <th scope="col" colspan="4">Number of Leave Taken</th>
                    </tr>
                    <tr>
                        <th scope="col">Casual</th>
                        <th scope="col">Vacation</th>
                        <th scope="col">Other</th>
                        <th scope="col">Special</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(!empty($all_leaves)): ?>
                    <?php $__currentLoopData = $all_leaves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($all_leave['epf_no']); ?></td>
                        <td><?php echo e($all_leave['user_name']); ?></td>
                        <td><?php echo e($all_leave['designation']); ?></td>
                        <td><?php echo e($all_leave['team']); ?></td>
                        <td><?php echo e($all_leave['cassual_count']); ?></td>
                        <td><?php echo e($all_leave['vacasion_count']); ?></td>
                        <td><?php echo e($all_leave['other_count']); ?></td>
                        <td><?php echo e($all_leave['special_leaves']); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <tr><td class="td-bgcolor-white">No records</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    </div>
</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\leave_manage\resources\views/pdf/allLeaveSummaryReport.blade.php ENDPATH**/ ?>