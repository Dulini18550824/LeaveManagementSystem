

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
    <div class="card-header">
    Report
    </div>
    <div class="card-body">
        <h5 class="card-title">Leave Summary Report</h5>

        <div class="mb-4">
            <div><label class="lbl-width-130">User:</label>HOD</div>
            <div><label class="lbl-width-130">Raport Date:</label><?php echo e(Carbon\Carbon::now()->isoFormat('YYYY-MM-DD')); ?></div>
        </div>

        <!-- Leave Details -->
        <div class="table-max-height-300">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col" rowspan="2" class="align-top">EPF Number</th>
                        <th scope="col" rowspan="2" class="align-top">Employee Name</th>
                        <th scope="col" rowspan="2" class="align-top">Employee Designation</th>
                        <th scope="col" rowspan="2" class="align-top">Employee Team</th>
                        <th scope="col" colspan="4">Number of Leave Taken</th>
                    </tr>
                    <tr>
                        <th scope="col">Casual</th>
                        <th scope="col">Vacation</th>
                        <th scope="col">Other</th>
                        <th scope="col">Special</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(!empty($all_leaves)): ?>
                    <?php $__currentLoopData = $all_leaves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($all_leave['epf_no']); ?></td>
                        <td><?php echo e($all_leave['user_name']); ?></td>
                        <td><?php echo e($all_leave['designation']); ?></td>
                        <td><?php echo e($all_leave['team']); ?></td>
                        <td><?php echo e($all_leave['cassual_count']); ?></td>
                        <td><?php echo e($all_leave['vacasion_count']); ?></td>
                        <td><?php echo e($all_leave['other_count']); ?></td>
                        <td><?php echo e($all_leave['special_count']); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <tr><td class="td-bgcolor-white">No records</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <a class="btn btn-primary f-r" href="/reports/all/leave-summary-pdf">Download</a>
    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\leave_manage\resources\views/report/all_leave_summary.blade.php ENDPATH**/ ?>