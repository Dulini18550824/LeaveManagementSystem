
<?php $__env->startSection('content'); ?>
<leave-manage :leaves='<?php echo e(json_encode($leaves)); ?>'></leave-manage>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\leave_manage\resources\views/leave/manage.blade.php ENDPATH**/ ?>