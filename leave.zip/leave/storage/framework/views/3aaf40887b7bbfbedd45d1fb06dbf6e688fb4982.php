
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-header">
            Short Leave Application
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(action('LeaveController@shortLeave')); ?>">
            <?php echo csrf_field(); ?>
            <?php if(session()->has('message')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session()->get('message')); ?>

                </div>
            <?php endif; ?>
            <?php if(session()->has('msg')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('msg')); ?>

                </div>
            <?php endif; ?>
                <div class="row mb-4">

                    <div class="col">
                        <label for="start_date">Date<label class="error-msg">*</label></label>
                        <input type="date" min="<?php echo e(Carbon\Carbon::today()->format('Y-m-d')); ?>" class="form-control" placeholder="Optional" name="start_date" required 
                        value="<?php echo e(old('start_date')); ?><?php echo e($leave!=NULL && property_exists($leave, 'start_date') ? Carbon\Carbon::parse($leave->start_date)->format('Y-m-d'):''); ?>">
                        <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="error-msg" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col">
                        <label for="reason">Reason<label class="error-msg">*</label></label>
                        <input type="text" class="form-control" placeholder="" name="reason" value="<?php echo e(old('reason')); ?>">
                        <?php $__errorArgs = ['reason'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="error-msg" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col">
                        <label for="time_from">Time from<label class="error-msg">*</label></label>
                        <input type="time" class="form-control" name="time_from" required 
                        value="<?php echo e(old('time_from')); ?><?php echo e($leave!=NULL && property_exists($leave, 'start_date') ? Carbon\Carbon::parse($leave->time_from)->format('H:i'):''); ?>" min="<?php echo e(auth()->user()->work_from); ?>">
                        <?php $__errorArgs = ['time_from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="error-msg" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col">
                        <label for="time_to">Time to<label class="error-msg">*</label></label>
                        <input type="time" class="form-control" placeholder="Optional" name="time_to" required 
                        value="<?php echo e(old('time_to')); ?><?php echo e($leave!=NULL && property_exists($leave, 'start_date') ? Carbon\Carbon::parse($leave->time_to)->format('H:i'):''); ?>" max="<?php echo e(auth()->user()->work_to); ?>">
                        <?php $__errorArgs = ['time_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="error-msg" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                </div>
                
                <?php if($leave!=NULL && property_exists($leave, 'start_date')): ?>
                <input type="hidden" name="leave_id" value="<?php echo e($leave->id); ?>">
                <?php endif; ?>

                <button type="submit" class="btn btn-primary" style="float: right;">Submit</button>

            </form>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\leave\resources\views/leave/short.blade.php ENDPATH**/ ?>