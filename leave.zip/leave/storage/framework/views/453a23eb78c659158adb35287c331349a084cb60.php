

<?php $__env->startSection('content'); ?>
<div class="container">
    <div>
        <h5 class="card-title"><?php if($type == 'short'): ?> Short <?php endif; ?> Leave Detail Report Employee Wise</h5>

        <!-- Leave Details -->
        <div class="table-max-height-300">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col" class="align-top">EPF Number</th>
                        <th scope="col" class="align-top">Employee Name</th>
                        <th scope="col">Team</th>
                        <th scope="col"></th> 
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user->epf_no); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->team->name); ?></td>
                        <?php if($type == 'all'): ?>
                        <td><a class="btn btn-primary" href="/reports/leave-detail/<?php echo e($user->id); ?>">View Report</a></td>
                        <?php else: ?>
                        <td><a class="btn btn-primary" href="/reports/shortLeave-detail/<?php echo e($user->id); ?>">View Report</a></td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\leave_manage\resources\views/report/users_list.blade.php ENDPATH**/ ?>