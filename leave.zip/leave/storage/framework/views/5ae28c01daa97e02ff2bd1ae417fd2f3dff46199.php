

<?php $__env->startSection('content'); ?>
<div class="container">
    <label for="">Employee Name: <?php echo e($user_name); ?></label>
    <user-calendar :data='<?php echo json_encode($data, 15, 512) ?>'></user-calendar>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\leave_manage\resources\views/report/user_calendar.blade.php ENDPATH**/ ?>