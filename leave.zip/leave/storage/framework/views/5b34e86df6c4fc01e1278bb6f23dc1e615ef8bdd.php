
<?php $__env->startSection('content'); ?>

<div class="table-padding">

    <?php if(session()->has('message')): ?>
        <div class="alert alert-danger">
            <?php echo e(session()->get('message')); ?>

        </div>
    <?php endif; ?>
    <?php if(session()->has('msg')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('msg')); ?>

        </div>
    <?php endif; ?>
    
    <h3>Edit Leave</h3>
    <table class="table table-striped">
    <thead>
        <tr>
        <th>Reason</th>
        <th>Date of commencing leave</th>
        <th>Date of resuming duties</th>
        <th>From</th>
        <th>To</th>
        <th></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $leaves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($leave->reason); ?></td>
            <td><?php echo e(\Carbon\Carbon::parse($leave->start_date)->format('j F, Y')); ?></td>

            <?php if($leave->leave_type != 3): ?>
            <td><?php echo e(\Carbon\Carbon::parse($leave->end_date)->format('j F, Y')); ?></td>
            <?php else: ?>
            <td>-</td>
            <?php endif; ?>
            
            <?php if($leave->leave_type == 3): ?>
            <td><?php echo e(\Carbon\Carbon::parse($leave->time_from)->format('g:i A')); ?></td>
            <td><?php echo e(\Carbon\Carbon::parse($leave->time_to)->format('g:i A')); ?></td>
            <?php else: ?>
            <td>-</td>
            <td>-</td>
            <?php endif; ?>

            <?php if($leave->leave_type == 1): ?>
            <td>
                <a href="/leave/<?php echo e($leave->id); ?>" type="button" class="btn btn-success">Edit</a>
                <a href="/leave/<?php echo e($leave->id); ?>/delete" type="button" class="btn btn-danger">Delete</a>
            </td>
            <?php elseif($leave->leave_type == 3): ?>
            <td>
                <a href="/leave/short-leave/<?php echo e($leave->id); ?>" type="button" class="btn btn-success">Edit</a>
                <a href="/leave/<?php echo e($leave->id); ?>/delete" type="button" class="btn btn-danger">Delete</a>
            </td>
            <?php elseif($leave->leave_type == 4): ?>
            <td>
                <a href="/leave/other/<?php echo e($leave->id); ?>" type="button" class="btn btn-success">Edit</a>
                <a href="/leave/<?php echo e($leave->id); ?>/delete" type="button" class="btn btn-danger">Delete</a>
            </td>
            <?php elseif($leave->leave_type == 5): ?>
            <td>
                <a href="/leave/special/<?php echo e($leave->id); ?>" type="button" class="btn btn-success">Edit</a>
                <a href="/leave/<?php echo e($leave->id); ?>/delete" type="button" class="btn btn-danger">Delete</a>
            </td>
            <?php endif; ?>

        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
    </tbody>
    </table>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\leave_manage\resources\views/leave/edit.blade.php ENDPATH**/ ?>