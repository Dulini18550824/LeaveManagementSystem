
<?php $__env->startSection('content'); ?>
<div class="container">
<div class="card">
  <div class="card-header">
    Other Leave Application
  </div>
  <div class="card-body">
      <form method="POST" action="<?php echo e(action('LeaveController@otherLeave')); ?>">
      <?php echo csrf_field(); ?>
      <?php if(session()->has('message')): ?>
          <div class="alert alert-danger">
              <?php echo e(session()->get('message')); ?>

          </div>
      <?php endif; ?>
      <?php if(session()->has('msg')): ?>
          <div class="alert alert-success">
              <?php echo e(session()->get('msg')); ?>

          </div>
      <?php endif; ?>
          <div class="row mb-4">
                <div class="col">
                    <label for="start_date">Date of commencing leave<label class="error-msg">*</label></label>
                    <input type="date" min="<?php echo e(Carbon\Carbon::today()->format('Y-m-d')); ?>" class="form-control" placeholder="Optional" id="start_date" name="start_date" required 
                    value="<?php echo e(old('start_date')); ?><?php echo e($leave!=NULL ? Carbon\Carbon::parse($leave->start_date)->format('Y-m-d'):''); ?>" onchange="getDiff();">
                    <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="error-msg" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
        
                <div class="col">
                    <label for="end_date">Date of resuming duties<label class="error-msg">*</label></label>
                    <input type="date" min="<?php echo e(Carbon\Carbon::today()->format('Y-m-d')); ?>" class="form-control" placeholder="Optional" id="end_date" name="end_date" required 
                    value="<?php echo e(old('end_date')); ?><?php echo e($leave!=NULL ? Carbon\Carbon::parse($leave->end_date)->format('Y-m-d'):''); ?>" onchange="getDiff();">
                    <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="error-msg" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="col">
                    <label for="no_of_days">No. of days leave apply for<label class="error-msg">*</label></label>
                    <input type="number" class="form-control" placeholder="" id="no_of_days" name="no_of_days" value="<?php echo e(old('no_of_days')); ?><?php echo e($leave!=NULL ? $leave->no_of_days : ''); ?>">
                    <?php $__errorArgs = ['no_of_days'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="error-msg" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
    
              <div class="col">
                  <label for="reason">Reason for leave<label class="error-msg">*</label></label>
                  <select id="reason" class="form-control" placeholder="" name="reason" value="<?php echo e(old('reason')); ?>">
                    <option value="Academic (Block) Leave" <?php if($leave!=NULL && $leave->reason == 'Academic (Block) Leave'): ?> <?php echo e('selected'); ?> <?php endif; ?>>Academic (Block) Leave</option>
                    <option value="Duty Leave"<?php if($leave!=NULL && $leave->reason == 'Duty Leave'): ?> <?php echo e('selected'); ?> <?php endif; ?>>Duty Leave</option>
                    <option value="Election Leave"<?php if($leave!=NULL && $leave->reason == 'Election Leave'): ?> <?php echo e('selected'); ?> <?php endif; ?>>Election Leave</option>
                    <option value="Other"<?php if($leave!=NULL && $leave->reason == 'Other'): ?> <?php echo e('selected'); ?> <?php endif; ?>>Other</option>
                  </select>
                  <?php $__errorArgs = ['reason'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="error-msg" role="alert">
                          <strong><?php echo e($message); ?></strong>
                      </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
    
          </div>
    
          <div class="row mb-4">
              
          </div>

          <?php if($leave!=NULL): ?>
          <input type="hidden" name="leave_id" value="<?php echo e($leave->id); ?>">
          <?php endif; ?>

          <button type="submit" class="btn btn-primary" style="float: right;">Submit</button>
    
      </form>
    
    </div>
    </div>
</div>

<script>

    var holidays = <?php echo json_encode($holidays, 15, 512) ?>;

    function isWeekDay(day) {
        if(day.getDay() == 6 || day.getDay() == 0) {
            return true;
        } else {
            return false;
        }
    }

    function valildateHolidayCount(start, end) {
        var count = 0;
        var holi_count = 0;

        for (var d = start; d <= end; d.setDate(d.getDate() + 1)) {
            if (!isWeekDay( new Date(d) )) {
                var c_day = '';
                if (d.getDate().toString() < 10) {
                    var c_day = d.getFullYear().toString() + '-' + String(d.getMonth() + 1) + '-0' + d.getDate().toString();
                } else {
                    var c_day = d.getFullYear().toString() + '-' + String(d.getMonth() + 1) + '-' + d.getDate().toString();
                }
                
                holidays.forEach(function (index) { 
                    if ( index.date == c_day ) {
                        holi_count++;
                        return false;
                    }
                });
                count++;
            }
            
        }
        return count - holi_count;
    }

   
    function getDiff() { 
        var start_date = document.getElementById('start_date');
        var end_date = document.getElementById('end_date');
        var diff = 0;

        if (start_date.value != null && end_date.value != null) {
            var start = new Date(start_date.value);
            var end = new Date(end_date.value);

            diff = valildateHolidayCount(start, end) - 1;
            document.getElementById('no_of_days').value = diff;
        }
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Laravel Projects\Ongoing\Project_Leave Management System\leave_manage\resources\views/leave/other.blade.php ENDPATH**/ ?>