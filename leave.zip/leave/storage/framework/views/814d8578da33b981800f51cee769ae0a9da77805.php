

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
    <div class="card-header">
    Report
    </div>
    <div class="card-body">
        <h5 class="card-title">Short Leave Detail Report</h5>

        <!-- Employee Details -->
        <div class="mb-4">
            <div><label class="lbl-width-130">Employee Name:</label><?php echo e($user->name); ?></div>
            <div><label class="lbl-width-130">E-mail Address:</label><?php echo e($user->email); ?></div>
            <div><label class="lbl-width-130">Contact Number:</label>0<?php echo e($user->mobile_no); ?></div> 
            <div><label class="lbl-width-130">EPF Number:</label><?php echo e($user->epf_no); ?></div> 
            <div><label class="lbl-width-130">Designation:</label><?php echo e($user->designation); ?></div> 
            <div><label class="lbl-width-130">Team:</label><?php echo e($user->team->name); ?></div>
            <div><label class="lbl-width-130">Raport Date:</label><?php echo e(Carbon\Carbon::now()->isoFormat('YYYY-MM-DD')); ?></div>
        </div>

        <!-- Leave Details -->
        <div class="table-max-height-300">
            <table class="table table-striped">
                <thead>
                    <tr>
                    <th scope="col">Date</th>
                    <th scope="col">Reason</th>
                    <th scope="col">Time From</th> 
                    <th scope="col">Time To</th> 
                    </tr>
                </thead>
                <tbody>
                    <?php if($leaves->isNotEmpty()): ?>
                        <?php $__currentLoopData = $leaves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><?php echo date('Y-m-d', strtotime($leave->start_date)); ?></td>
                        <td><?php echo e($leave->reason); ?></td>
                        <td><?php echo e(Carbon\Carbon::parse($leave->time_from)->format('h:i A')); ?></td>
                        <td><?php echo e(Carbon\Carbon::parse($leave->time_to)->format('h:i A')); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <tr><td class="td-bgcolor-white">No leaves</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <?php if($id == NULL): ?>
        <a class="btn btn-primary f-r m-1" href="/reports/shortLeave-detail-pdf">Download</a>
        <?php else: ?>
        <a class="btn btn-primary f-r m-1" href="/reports/shortLeave-detail-pdf/<?php echo e($id); ?>">Download</a>
        <?php endif; ?>
    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Laravel Projects\Ongoing\Project_Leave Management System\leave_manage\resources\views/report/short_leave_detail.blade.php ENDPATH**/ ?>