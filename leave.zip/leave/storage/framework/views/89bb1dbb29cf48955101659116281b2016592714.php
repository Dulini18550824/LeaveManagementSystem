

<?php $__env->startSection('content'); ?>
<acting-manage :users='<?php echo e(json_encode($users)); ?>'></acting-manage>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Laravel Projects\Ongoing\Project_Leave Management System\leave_manage\resources\views/acting/index.blade.php ENDPATH**/ ?>