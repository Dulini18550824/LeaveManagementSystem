

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <?php if(\Auth::user()->user_type == 3): ?>
        <a href="/reports/leave-detail">
        <div class="card text-center mr-5 mb-5">
            <div class="card-body">
                <h5 class="card-title">Leave Detail Report</h5>
            </div>
        </div>
        </a>
        <?php endif; ?>

        <?php if(\Auth::user()->user_type == 3): ?>
        <a href="/reports/shortLeave-detail">
        <div class="card text-center mr-5 mb-5">
            <div class="card-body">
                <h5 class="card-title">Short Leave Detail Report</h5>
            </div>
        </div>
        </a>
        <?php endif; ?>

        <?php if(\Auth::user()->user_type == 3): ?>
        <a href="/reports/Balance-leave">
        <div class="card text-center mr-5 mb-5">
            <div class="card-body">
                <h5 class="card-title">Balance Leave Report</h5>
            </div>
        </div>
        </a>
        <?php endif; ?>

        <?php if(\Auth::user()->user_type == 3): ?>
        <a href="/reports/leave-status">
        <div class="card text-center mr-5 mb-5">
            <div class="card-body">
                <h5 class="card-title">Leave Status Report</h5>
            </div>
        </div>
        </a>
        <?php endif; ?>

        <?php if(\Auth::user()->user_type == 1 || \Auth::user()->user_type == 4): ?>
        <a href="/reports/all/leave-balance">
        <div class="card text-center mr-5 mb-5">
            <div class="card-body">
                <h5 class="card-title">Leave Balance Report</h5>
            </div>
        </div>
        </a>
        <?php endif; ?>

        <?php if(\Auth::user()->user_type == 1 || \Auth::user()->user_type == 4): ?>
        <a href="/reports/all/leave-summary">
        <div class="card text-center mr-5 mb-5">
            <div class="card-body">
                <h5 class="card-title">Leave Summary Report</h5>
            </div>
        </div>
        </a>
        <?php endif; ?>

        <?php if(\Auth::user()->user_type == 1 || \Auth::user()->user_type == 4): ?>
        <a href="/reports/all/leave-detail/<?php echo e('all'); ?>">
        <div class="card text-center mr-5 mb-5">
            <div class="card-body">
                <h5 class="card-title">Leave Detail Report Employee Wise</h5>
            </div>
        </div>
        </a>
        <?php endif; ?>

        <?php if(\Auth::user()->user_type == 1 || \Auth::user()->user_type == 4): ?>
        <a href="/reports/all/leave-detail/<?php echo e('short'); ?>">
        <div class="card text-center mr-5 mb-5">
            <div class="card-body">
                <h5 class="card-title">Short Leave Detail Report Employee Wise</h5>
            </div>
        </div>
        </a>
        <?php endif; ?>

        <a href="/reports/holiday">
        <div class="card text-center mr-5 mb-5">
            <div class="card-body">
                <h5 class="card-title">Holiday Report</h5>
            </div>
        </div>
        </a>
    
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\leave\resources\views/report/select.blade.php ENDPATH**/ ?>