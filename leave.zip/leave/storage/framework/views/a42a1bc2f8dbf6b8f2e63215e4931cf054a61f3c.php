

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
    <div class="card-header">
    Report
    </div>
    <div class="card-body">
        <h5 class="card-title">Balance Leave Report</h5>

        <!-- Employee Details -->
        <div class="mb-4">
            <div><label class="lbl-width-130">Employee Name:</label><?php echo e($user->name); ?></div>
            <div><label class="lbl-width-130">E-mail Address:</label><?php echo e($user->email); ?></div>
            <div><label class="lbl-width-130">Contact Number:</label>0<?php echo e($user->mobile_no); ?></div> 
            <div><label class="lbl-width-130">EPF Number:</label><?php echo e($user->epf_no); ?></div> 
            <div><label class="lbl-width-130">Designation:</label><?php echo e($user->designation); ?></div> 
            <div><label class="lbl-width-130">Team:</label><?php echo e($user->team->name); ?></div>
            <div><label class="lbl-width-130">Report Date:</label><?php echo e(Carbon\Carbon::now()->isoFormat('YYYY-MM-DD')); ?></div>
        </div>

        <!-- Leave Details -->
        <div class="table-max-height-300">
            <table class="table table-striped">
                <thead>
                    <tr>
                    <th scope="col">Type of Leave</th>
                    <th scope="col">Number of Leave Allocated for Year</th>
                    <th scope="col">Number of Leave Taken</th>
                    <th scope="col">Balance of Leave</th> 
                    </tr>
                </thead>
                <tbody>
                <tr>
                    <td>Casual Leave</td>
                    <td>21</td>
                    <td><?php echo e($leaves['casual']); ?></td>
                    <td><?php echo e(21 - $leaves['casual']); ?></td>
                    </tr>
                    <tr>
                    <td>Vacation Leave</td>
                    <td>24</td>
                    <td><?php echo e($leaves['vacation']); ?></td>
                    <td><?php echo e(24 - $leaves['vacation']); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <a class="btn btn-primary f-r m-1" href="/reports/balance-leave-pdf">Download</a>
    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\leave_manage\resources\views/report/balance_leave.blade.php ENDPATH**/ ?>