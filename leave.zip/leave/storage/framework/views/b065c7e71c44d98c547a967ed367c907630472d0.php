<!DOCTYPE html>
<html>
<head>
	<title>Leave Status Report</title>
</head>
<body>
	<h1>Leave Status Report</h1>
    <div class="container">
        <div class="card">
        <div class="card-header">
        Report
        </div>
        <div class="card-body">
            <h5 class="card-title">Leave Status Report</h5>
    
            <!-- Employee Details -->
            <div class="mb-4">
                <div><label class="lbl-width-130">Employee Name:</label><?php echo e($user->name); ?></div>
                <div><label class="lbl-width-130">E-mail Address:</label><?php echo e($user->email); ?></div>
                <div><label class="lbl-width-130">Contact Number:</label>0<?php echo e($user->mobile_no); ?></div> 
                <div><label class="lbl-width-130">EPF Number:</label><?php echo e($user->epf_no); ?></div> 
                <div><label class="lbl-width-130">Designation:</label><?php echo e($user->designation); ?></div> 
                <div><label class="lbl-width-130">Team:</label><?php echo e($user->team->name); ?></div>
                <div><label class="lbl-width-130">Raport Date:</label><?php echo e(Carbon\Carbon::now()->isoFormat('YYYY-MM-DD')); ?></div>
            </div>
    
            <!-- Leave Details -->
            <div class="table-max-height-300">
                <table class="table table-striped">
                    <thead>
                        <tr>
                        <th scope="col">Date of Commencing Leave</th>
                        <th scope="col">Type of Leave</th>
                        <th scope="col">Number of Days</th>
                        <th scope="col">Approval status</th>
                        <th scope="col">Approved date if approved</th> 
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($leaves->isNotEmpty()): ?>
                            <?php $__currentLoopData = $leaves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            <td><?php echo date('Y-m-d', strtotime($leave->start_date)); ?></td>
                            <td><?php echo e($leave->leaveType->type); ?> Leave</td>
                            <td><?php echo e($leave->no_of_days); ?></td>
                            <?php if($leave->status == 0): ?>
                            <td>Pending</td>
                            <?php elseif($leave->status == 1): ?>
                            <td>Approved</td>
                            <?php else: ?>
                            <td>Rejected</td>
                            <?php endif; ?>
        
                            <?php if($leave->approved_at != NULL): ?>
                            <td><?php echo date('Y-m-d', strtotime($leave->approved_at)); ?></td>
                            <?php else: ?>
                            <td>-</td>
                            <?php endif; ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <tr><td class="td-bgcolor-white">No leaves</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\leave_manage\resources\views/pdf/leaveStatusReport.blade.php ENDPATH**/ ?>