

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="table-padding">
            <h3>Employee Profiles</h3>
            <table class="table table-striped">
            <thead>
                <tr>
                    <th>EPF No.</th>
                    <th>Name</th>
                    <th>Team</th>
                    <th></th>
                </tr>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($user->epf_no); ?></th>
                    <th><?php echo e($user->name); ?></th>
                    <th><?php echo e($user->team->name); ?></th>
                    <th><a href="/profile/<?php echo e($user->id); ?>" class="btn btn-primary">View Profile</a></th>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </thead>
         </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\leave_manage\resources\views/user/emp-profiles.blade.php ENDPATH**/ ?>