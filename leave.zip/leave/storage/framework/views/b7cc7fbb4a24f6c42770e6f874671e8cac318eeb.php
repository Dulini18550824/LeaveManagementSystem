

<?php $__env->startSection('content'); ?>

<?php if(session()->has('success')): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <?php echo e(session()->get('success')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>

<?php if(session()->has('error_msg')): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <?php echo e(session()->get('error_msg')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>


<div class="row">
  <div class="col-lg-15 mx-auto">
    <div class="card">
        <div class="card-header">
            Users
        </div>
        <div class="card-body">
            <!-- Users Details -->
            <div class="mb-4">
                <table class="table table-bordered mb-5">
                    <thead>
                        <tr class="table-success">
                            <th scope="col">Name</th>
                            <th scope="col">Email</th>
                            <th scope="col">User Type</th>
                            <th scope="col">EPF No</th>
                            <th scope="col">Designation</th>
                            <th scope="col">Team</th>
                            <th scope="col">Phone No</th>
                            <th scope="col">Verify</th>
                            <th scope="col">Manage</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($data->name); ?></th>
                            <td><?php echo e($data->email); ?></td>
                            <td>
                                <?php if($data->user_type == 1): ?> <p>HOD</p>
                                <?php elseif($data->user_type == 2): ?> <p>ACTING</p>
                                <?php elseif($data->user_type == 3): ?> <p>EMPLOYEE</p>
                                <?php elseif($data->user_type == 4): ?> <p>REGISTAR</p>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($data->epf_no); ?></td>
                            <td><?php echo e($data->designation); ?></td>
                            <?php if(!empty($data->team)): ?>
                            <td><?php echo e($data->team->name); ?></td>
                            <?php else: ?>
                            <td>None</td>
                            <?php endif; ?>
                            <?php if(!empty($data->mobile_no)): ?>
                            <td><?php echo e($data->mobile_no); ?></td>
                            <?php else: ?>
                            <td>None</td>
                            <?php endif; ?>
                            <td>
                                <?php if($data->is_verified === "true"): ?>
                                 <p>Verified</p>
                                <?php else: ?>
                                 <a href="<?php echo e(route('admin.users.verify', $data->id)); ?>" class="btn btn-primary">Verify</a>
                                <?php endif; ?>
                                </td>
                            <td>
                                <a href="<?php echo e(route('admin.users.edit', $data->id)); ?>" class="btn btn-primary">Edit</a>
                                <a href="<?php echo e(route('admin.users.delete', $data->id)); ?>" class="btn btn-danger">Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                <div class="d-flex justify-content-center">
                    <?php echo $users->links(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\leave\resources\views/user/index.blade.php ENDPATH**/ ?>