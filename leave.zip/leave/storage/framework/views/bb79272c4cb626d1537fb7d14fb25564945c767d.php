

<?php $__env->startSection('content'); ?>
<div class="container">
    <h3>Holiday Report</h3>
    Year: 2021 
    <table class="table table-striped">
        <thead>
            <tr>
            <th scope="col">Date</th>
            <th scope="col">Holoday</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $holidays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $holiday): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($holiday->date); ?></td>
            <td><?php echo e($holiday->name); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>
    <a class="btn btn-primary f-r m-1" href="/reports/holidays-pdf">Download</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\leave\resources\views/report/holiday.blade.php ENDPATH**/ ?>