<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div class="container">
    <div class="card">
    <div class="card-header">
    Report
    </div>
    <div class="card-body">
        <h5 class="card-title">Leave Balance Report</h5>

        <div class="mb-4">
            <div><label class="lbl-width-130">User:</label>HOD</div>
            <div><label class="lbl-width-130">Raport Date:</label><?php echo e(Carbon\Carbon::now()->isoFormat('YYYY-MM-DD')); ?></div>
        </div>

        <!-- Leave Details -->
        <div class="table-max-height-300">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col" rowspan="2" class="align-top">EPF Number</th>
                        <th scope="col" rowspan="2" class="align-top">Employee Name</th>
                        <th scope="col" colspan="2">Number of Leave Allocated for Year</th>
                        <th scope="col" colspan="2">Number of Leave Taken</th>
                        <th scope="col" colspan="2">Balance of Leave</th> 
                    </tr>
                    <tr>
                        <th scope="col">Casual</th>
                        <th scope="col">Vacation</th>
                        <th scope="col">Casual</th>
                        <th scope="col">Vacation</th>
                        <th scope="col">Casual</th>
                        <th scope="col">Vacation</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(!empty($user_leaves)): ?>
                    <?php $__currentLoopData = $user_leaves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user_leave['epf_no']); ?></td>
                        <td><?php echo e($user_leave['user_name']); ?></td>
                        <td>21</td>
                        <td>24</td>
                        <td><?php echo e($user_leave['cassual_count']); ?></td>
                        <td><?php echo e($user_leave['vacasion_count']); ?></td>
                        <td><?php echo e(21 - $user_leave['cassual_count']); ?></td>
                        <td><?php echo e(24 - $user_leave['vacasion_count']); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <tr><td class="td-bgcolor-white">No records</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    </div>
</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\leave\resources\views/pdf/allLeaveBalanceReport.blade.php ENDPATH**/ ?>