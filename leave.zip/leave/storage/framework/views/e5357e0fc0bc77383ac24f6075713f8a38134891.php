
<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if(session()->has('message')): ?>
        <div class="alert alert-danger">
            <?php echo e(session()->get('message')); ?>

        </div>
    <?php endif; ?>
    <?php if(session()->has('msg')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('msg')); ?>

        </div>
    <?php endif; ?>
    <div class="row">

        <div class="col-md-12 d-flex justify-content-center">
            <div class="card text-center mr-5 mb-5" style="width: 18rem;">
                <div class="card-body">
                    <h5 class="card-title">Short Leave</h5>
                    <p class="card-text">Click here to apply for a Short Leave.</p>
                    <a href="/leave/short-leave" class="btn btn-primary">Apply</a>
                    <a href="/leave/edit/3" class="btn btn-primary">Edit</a>
                </div>
            </div>

        <div class="card text-center mr-5 mb-5" style="width: 18rem;">
            <div class="card-body">
                <h5 class="card-title">Full day / Half day Leave</h5>
                <p class="card-text">Click here to apply for a Full day / Half day Leave.</p>
                <a href="/leave" class="btn btn-primary">Apply</a>
                <a href="/leave/edit/1" class="btn btn-primary">Edit</a>
            </div>
        </div>
        </div>
    </div>

    <div class="col-md-12 d-flex justify-content-center">
        <div class="row">
            <div class="card text-center mr-5 mb-5" style="width: 18rem;">
                <div class="card-body">
                    <h5 class="card-title">Other Leave</h5>
                    <p class="card-text">Click here to apply for a Leave (Academic (block), Duty, Election and Other).</p>
                    <a href="/leave/other" class="btn btn-primary">Apply</a>
                    <a href="/leave/edit/4" class="btn btn-primary">Edit</a>
                </div>
            </div>

            <div class="card text-center mr-5 mb-5" style="width: 18rem;">
                <div class="card-body">
                    <h5 class="card-title">Special Leave</h5>
                    <p class="card-text">Click here to apply for a Special Leave (Maternity Leave, Overseas Leave, etc.). Your request need to approve by the Registar.</p>
                    <a href="/leave/special" class="btn btn-primary">Apply</a>
                    <a href="/leave/edit/5" class="btn btn-primary">Edit</a>
                    
                </div>
            </div>
        
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Laravel Projects\Ongoing\Project_Leave Management System\leave_manage\resources\views/leave/select.blade.php ENDPATH**/ ?>