<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="mb-4">
        <div><label class="lbl-width-130">Name:</label><?php echo e($leave->user->name); ?></div>
        <div><label class="lbl-width-130">Email Address:</label><?php echo e($leave->user->email); ?></div>
        <div><label class="lbl-width-130">Contact Number:</label>0<?php echo e($leave->user->mobile_no); ?></div>
        <div><label class="lbl-width-130">Designation:</label><?php echo e($leave->user->designation); ?></div> 
        <div><label class="lbl-width-130">First Appointment Date:</label><?php echo e($leave->user->first_appointment); ?></div>
        <div><label class="lbl-width-130">Working Hours:</label><?php echo e($leave->user->work_from); ?> - <?php echo e($leave->user->work_to); ?></div>
        <div><label class="lbl-width-130">Number of days leave apply for:</label><?php echo e($leave->no_of_days); ?></div>
        <div><label class="lbl-width-130">Reason for leave:</label><?php echo e($leave->reason); ?></div>
        <div><label class="lbl-width-130">Date of comencing leave:</label><?php echo e($leave->start_date); ?></div>
        <div><label class="lbl-width-130">Date of resuming leave:</label><?php echo e($leave->end_date); ?></div>
        <div><label class="lbl-width-130">Date of leave apply:</label><?php echo e(Date('Y-m-d')); ?></div>

    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\leave\resources\views/pdf/specialleaveForm.blade.php ENDPATH**/ ?>